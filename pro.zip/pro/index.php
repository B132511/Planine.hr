<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="autor" content="Borna Alvir">
    <meta name="datum" content="16.01.2022.">
    <link rel="stylesheet" type="text/css" href="CSS/Glavni.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <title>HR PLANINE</title>
</head>

<body>

    <?php
        include_once ("meni.php");
        include_once ("slika.php");
    ?>

    <section class = "section_prazni"></section>

    <section class = "section_id1">
        <h1>Projektni zadatak - Varaždin</h1>
        <p class = "section_id1_donji_razmak";>
            Uloge: administrator, moderator, registrirani korisnik i anonimni/neregistrirani korisnici.
        </p>
        <p class = "section_id1_donji_razmak";>
            Sustav omogućuje kreiranje javne i privatne galerije slika hrvatskih planina. Sustav mora imati mogućnost prijave i odjave korisnika sa sustava. U sustavu postoji jedan ugrađeni administrator (korisničko ime: admin, lozinka: foi). Administrator je prijavljeni korisnik koji ima vrstu jednaku jedan. Sustav obavezno sadrži stranicu o_autoru.html (poveznica na stranicu mora biti u zaglavlju svake stranice) u kojoj se nalaze osobni podaci autora (svi podaci su obavezni): ime, prezime, broj indeksa, mail (obavezno FOI mail), centar, godina (akademska godina prvog upisa kolegija IWA) i slika JPG formata veličine 300x400px (npr. kao na osobnoj iskaznici ili indeksu).
        </p>
        <p class = "section_id1_donji_razmak" ;>
            Anonimni/neregistrirani korisnik može vidjeti galeriju javnih slika hrvatskih planina sortirano silazno po datumu i vremenu slikanja. Može filtrirati podatke na temelju naziva planine i/ili vremenskog razdoblja slikanja. Vremensko razdoblje se definira datumom i vremenom od i do. Klikom na sliku dobivaju se detaljne informacije o slici sa informacijama o planini u koju slika pripada te imenom i prezimenom korisnika koji je postavio sliku. Korisnik može kliknuti na naziv planine te se vraća na galeriju slika i odmah vidi samo slike te planine. Korisnik može kliknuti na prezime korisnika i dobiva galeriju javnih slika tog korisnika te opet može kliknuti na sliku i doći do detaljnih informacija slike.
        </p>
        <p class = "section_id1_donji_razmak";>
            Registrirani korisnik uz svoje funkcionalnosti ima i sve funkcionalnosti kao i neprijavljeni korisnik. Korisnik može dodavati nove slike planina. Prilikom dodavanja bira planinu, unosi url do slike na webu, definira datum i vrijeme slikanja, daje naziv i opis slici, automatski se status slike postavlja na 1 (javna). Korisnik vidi popis svih svojih slika sa informacijom o statusu. Korisnik može ažurirati podatke o slici pri čemu može promijeniti status slike (0 - privatna) ili (1 – javna).
        </p>
        <p class = "section_id1_donji_razmak";>
            Moderator uz svoje funkcionalnosti ima i sve funkcionalnosti kao i registrirani korisnik te dodano vidi popis svih planina za koje je zadužen. Odabirom planine može vidjeti popis svih javnih slika koje su dodane za tu planinu sa imenom i prezimenom osobe koja je tu sliku postavila. Klikom na prezime dobiva galeriju javnih slika odabranog korisnika. Ako želi može blokirati korisnika (blokiran=1) čime sve njegove slike postaju privatne i korisnik ne može dodavati nove slike dok ga administrator ne od blokira (blokiran=0).
            </p>
        <p class = "section_id1_donji_razmak";>
            Administrator uz svoje funkcionalnosti ima i sve funkcionalnosti kao i moderator. Unosi, ažurira i pregledava korisnike sustava te definira i ažurira njihove tipove.Unosi, pregledava i ažurira planine (npr. Dinara, Velebit, ...) te dodjeljuje moderatore za planinu. Jedna planina može imati jednog ili više moderatora, jedan moderator može biti zadužen za više planina. Administrator vidi popis blokiranih korisnika (blokiran=1) te ih može od blokirati (blokiran=0). Administrator vidi statistiku broja privatnih i javih slika po korisniku sortirano prezimenu korisnika.
            </p>
        <p class = "section_id1_donji_razmak";>
            Napomena: Svi datumi moraju se unositi od strane korisnika i prikazati korisniku u formatu „d.m.Y“, a vrijeme (00:00:00 – 23:59:59) u obliku „H:i:s“ (ne koristiti date i time HTML tip za input element). Format „d.m.Y” predstavlja kod PHP date funkciji i preslikava se na hrvatski format „dd.mm.gggg”. Format „H:i:s” predstavlja kod PHP date funkciji i preslikava se na hrvatski format „hh.mm.ss”. Poslužitelj se naziva localhost a baza podataka je iwa_2020_vz_projekt. Korisnik za pristup do baze podataka naziva se iwa_2020 a lozinka je foi2020. Kod izrade projektnog rješenja treba se točno držati uputa i NE SMIJE se mijenjati (naziv poslužitelja, baze podataka, struktura tablica, korisnik i lozinka). Završeno rješenje projektnog zadatka treba poslati kroz sustav za predaju rješenja nakon čega slijedi obavijest i dogovor o obrani projekta. Obrana projektnog rješenja se obavlja na računalu i bazi podataka nastavnika.
        </p>
        <h1>Popravak 01</h1>
        <p class = "section_id1_donji_razmak";>
            NK:
            - Klikom na sliku dobivaju prikazuje se pogrešni format vremena slikanja (vidi napomenu). 
            Korisnik može kliknuti na prezime korisnika (ne korisničko ime) i dobiva galeriju javnih slika tog korisnika. 
            Klikom na korisničko ime (u vašem slučaju => treba ispraviti na prezime) otvara se nepostojeća lokacija na poslužitelju jer datoteka javni_profil.php ne postoji. (vidi napomenu). Nije isto javni_profil.php i Javni_profil.php
            - Slike korisnika koji je blokiran ne prikazuju se u galeriji.
            <br><br>
            RK:
            - Moj profi - prijenos nove slike. Klikom na poveznicu otvara se nepostojeća lokacija na poslužitelju jer datoteka registracija_slike.php ne postoji. (vidi napomenu). Nije isto registracija_slike.php i Registracija_slike.php
            - Korisnik koji je postavio fotografiju može ažurirati i ostale podatke o slici (ne samo promijeniti status).
            <br><br>
            M:
            - Korisničke akcije - Moderiranje planine. Klikom na prezime dobiva galeriju javnih slika odabranog korisnika. U vašem slučaju otvara se nepostojeća lokacija na poslužitelju jer datoteka javni_profil_moderator.php ne postoji. (vidi napomenu). Nije isto javni_profil_moderator.php i Javni_profil_moderator.php
            - Blokiranje korisnika nije bilo moguće provjeriti.
            <br><br>
            A:
            - Stranica pregled korisnika. Prikažite sliku korisnika u tablici. Nakon editiranja potrebno je osvježiti stranicu da se ažuriraju podaci (provjerite u čemu je problem).
            <br><br>
            O:
            - Stranica autora treba biti u ekstenziji .html
            - Stranica Registracija mora biti vidljiva samo administratoru.
            Klikom na poveznicu otvara se nepostojeća lokacija na poslužitelju jer datoteka registracija_korisnika.php ne postoji. (vidi napomenu)
            Nije isto registracija_korisnika.php i Registracija_korisnika.php
            <br><br>
            N:
            - Svi datumi moraju se unositi od strane korisnika i prikazati korisniku u formatu d.m.Y, a vrijeme H:i:s
            - IWA poslužitelj razlikuje velika i mala slova datoteka i ekstenzija!
        </p>
        <h1>Change log</h1>
        <h2>V.01</h1>
        <p class = "section_id1_donji_razmak";>
            NK: <br>
            - Klikom na sliku unutar galerije popravljen format prikaza iz Y.m.d H:i:s u d.m.Y H:i:s<br>
            - Klikom na korisničko ime za prikaz javnog profila pomaknuta na korisničko prezime<br>
            - Otvara se nepostojeća lokacija na poslužitelju, promijenjen poziv na ispravnu skriptu<br>
            - Slike blokiranog korisnika se ne prikazuju u javnoj galeriji, jer kada moderator blokira korisnika njegove slike automatski postaju privatne tako dugo kad se ne vrati pristup sustavu<br>
            RK:<br>
            - Klikom na poveznicu otvara se nepostojeća lokacija na poslužitelju, promijenjen poziv na ispravnu skriptu<br>
            - Skripta koja je omogućavala ažuriranje statusa vlastite slike RK, proširena tako da omogućuje ažuriranje svih podataka slike<br>
            M:<br>
            - Klikom na poveznicu otvara se nepostojeća lokacija na poslužitelju, promijenjen poziv na drugu skriptu<br>
            A:<br>
            - Stranica pregled korisnika, skripta sada prikazuje slike korisnika veličine 100px 100px<br>
            - Ažuriranje stranice pregleda korisnika sada automatski osvježuje rezultate<br>
            O:<br>
            - Stranica autora je izmijenjena u HTML oblik stranice<br>
            - Registracija korisnika je pomaknuta s glavnog navigacijskog izbornika, na izbornik  korisničke akcije kome može pristupiti samo osoba s admin pravima<br>
            - Otvara se nepostojeća lokacija na poslužitelju, promijenjen poziv na ispravnu skriptu<br>
            - Statistika ima dodatnu tablicu koja prikazuje ukupne brojeve baze podataka i postotak javnih i privatnih slika<br>
            - Skripta mojeg profila je proširena i prikazuje sliku korisnika veličine 150x s 250x<br>
        </p>
        <h2>V.02</h1>
        <p class = "section_id1_donji_razmak";>
            O:<br>
            - Pregled korisnika sada ispravno prikazuje status korisnika s riječima blokiran/nije blokiran<br>
            - V.01 je promijenila kod iz php u html verziju, ali tek sada je skripta promijenjena u ispravnu datotečnu ekstenziju (.html)<br>
        </p>
        
    </section>

    <section class = "section_prazni"></section>

    <?php
        include_once ("footer.php");
    ?>
    
</body>

</html>