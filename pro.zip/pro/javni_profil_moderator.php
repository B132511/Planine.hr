<?php

  session_start();
  
  include_once("baza.php");
  include_once("meni.php");
  include_once ("slika.php");
  include("prazni.php");

  $get_podaci = $_SERVER["QUERY_STRING"];

  $podaci_s_get_ex = explode("&",$get_podaci);
  
  $get_planina_id = (int) filter_var($podaci_s_get_ex[0],FILTER_SANITIZE_NUMBER_INT);
  $get_korisnik_id = (int) filter_var($podaci_s_get_ex[1],FILTER_SANITIZE_NUMBER_INT);
  $get_slika_id = (int) filter_var($podaci_s_get_ex[2],FILTER_SANITIZE_NUMBER_INT);
  
  $veza = spojiSeNaBazu();

?>

<!DOCTYPE html>
<html lang="en">
  <head>
      <meta charset="utf-8">
      <meta name="autor" content="Borna Alvir">
      <meta name="datum" content="16.01.2022.">
      <link rel="stylesheet" type="text/css" href="CSS/Glavni.css">
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
      <title>HR PLANINE</title>
  </head>
  <body>
    <section class="section_id8">
      <?php

        if (isset($get_korisnik_id) && !empty($get_korisnik_id) && $_SERVER["REQUEST_METHOD"] == 'GET') {

          echo "<section class = \"section_id8\">";

          echo "<h1>Javni profil</h1>";

          $veza = spojiSeNaBazu();

          $upit = "SELECT * FROM korisnik WHERE korisnik_id =\"$get_korisnik_id\"";

          $rezultat = izvrsiUpit($veza, $upit);

          while ($podaci = mysqli_fetch_array($rezultat)) {
            echo "<div>";
            echo "<p><b>Korisničko ime:</b> $podaci[2]</p>";
            echo "<p><b>Ime:</b> $podaci[4]</p>";
            echo "<p><b>Prezime:</b> $podaci[5]</p>";
            echo "<p><b>Email:</b> $podaci[6]</p>";
            echo "<p><b>Slika:</b> $podaci[8]</p>";
            if ($podaci[7] == 0){
              echo "<p style='color:green'><b>Status:</b> ";
              echo "Uzoran korisnik </p>";
            }
            else {
              echo "<p style='color:red'>Status: ";
              echo "Blokiran korisnik</p>";
            }
            echo "</p>";

            echo "<a href = \"editiranje_javnog_profila.php?$podaci[0]\"><input class=\"gumb\" type=\"submit\" value=\"Promjena statusa korisnika\" /></a>";
            echo "</div>";
          }
        
          echo "<h1>Slike korisnika</h1>";

          echo "<section class = \"section_id9\">";

          $upit = "SELECT * FROM slika WHERE korisnik_id =\"$get_korisnik_id\"";

          $rezultat = izvrsiUpit($veza, $upit);
          
          while ($podaci = mysqli_fetch_array($rezultat)) {
            if ($podaci[7] == '1') {
            echo "<div class = \"moj_profil_slike\">";
            echo "<a href=\"detaljne_info_o_slici.php?planina_id=$podaci[1]&korisnik_id=$podaci[2]&slika_id=$podaci[0]&\"><img border=\"0\" alt=\"foi.hr\" src=\"$podaci[4]\" width=\"350px\" height=\"250px\"></a>";
            echo "</div>";
            }
          }

          echo "</section>";
          echo "</section>";

        }
        
      ?>
    </section>
      <?php
        zatvoriVezuNaBazu($veza);
        include("prazni.php");
        include_once("footer.php");
      ?>
  </body>

</html>