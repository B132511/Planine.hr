<?php

  session_start();

  include_once ("meni.php");
  include_once ("slika.php");
  include_once ("baza.php");
  include ("prazni.php");

  $veza = spojiSeNaBazu();

  echo "<section class = \"section_id11\">";

  echo "<h1>STATISTIKA GALERIJE</h1>";

  if ($_SESSION["tip_korisnika"] == "0" && empty($_SERVER["QUERY_STRING"])) {
    echo "<div>";

    $upit = "SELECT
    k.korisnik_id  as `korisnik_id`,
    k.korisnicko_ime     as `username`,
    k.ime     as `ime`,
    k.prezime     as `prezime`,
    count(s.slika_id) as `uk_slika`,
    count(CASE WHEN s.status = 0 THEN 1 END) as `Privatnih_slika`,
    count(CASE WHEN s.status = 1 THEN 1 END) as `Javnih_slika`
    FROM korisnik AS `k`
    left JOIN slika AS `s` ON (k.korisnik_id = s.korisnik_id)
    group by k.korisnik_id  
    ORDER BY `k`.`prezime` ASC";
    $rezultat_statistike = izvrsiUpit($veza, $upit);

    $uk_broj_slika = 0;
    $uk_broj_jav_slika = 0;
    $uk_broj_pri_slika = 0;

    echo "<Table>";
      echo "<thead>";
        echo "<tr>";
          echo "<th>ID KORISNIKA</th>";
          echo "<th>KORISNIČKI USERNAME</th>";
          echo "<th>IME</th>";
          echo "<th>PREZIME</th>";
          echo "<th>UK. BROJ SLIKA KORISNIKA</th>";
          echo "<th>BROJ PRIVATNIH SLIKA</th>";
          echo "<th>BROJ JAVNIH SLIKA</th>";
        echo "</tr>";
      echo "</thead>";
      echo "<tbody>";
            while ($podatak_statistike = mysqli_fetch_array($rezultat_statistike)) {
            echo "<tr>";
              echo "<td class = \"centar\">{$podatak_statistike[0]}</td>";
              echo "<td>{$podatak_statistike[1]}</td>";
              echo "<td>{$podatak_statistike[2]}</td>";
              echo "<td>{$podatak_statistike[3]}</td>";
              echo "<td class = \"centar\">{$podatak_statistike[4]}</td>";
              echo "<td class = \"centar\">{$podatak_statistike[5]}</td>";
              echo "<td class = \"centar\">{$podatak_statistike[6]}</td>";
            echo "</tr>";

            if ($podatak_statistike[4]) {
              $uk_broj_slika += $podatak_statistike[4];
            }
            if ($podatak_statistike[5]) {
              $uk_broj_jav_slika += $podatak_statistike[5];
            }
            if ($podatak_statistike[6]) {
              $uk_broj_pri_slika += $podatak_statistike[6];
            }
            
          }
      echo "</tbody>";
    echo "</table>";
    
    echo "<br>";
    $post_jav_slika = round(($uk_broj_jav_slika/$uk_broj_slika) * 100, 2) . "&#37;";
    $post_pri_slika = round(($uk_broj_pri_slika/$uk_broj_slika) * 100, 2) . "&#37;";

    echo "<Table>";
      echo "<thead>";
        echo "<tr>";
          echo "<th>UKUPNI BROJ SLIKA</th>";
          echo "<th>UKUPNI BROJ JAVNIH SLIKA</th>";
          echo "<th>UKUPNI BROJ PRIVATNIH SLIKA</th>";
          echo "<th>POSTOTAK JAVNIH SLIKA U GALERIJI</th>";
          echo "<th>POSTOTAK PRIVATNIH SLIKA U GALERIJI</th>";
        echo "</tr>";
      echo "</thead>";
      echo "<tbody>";
            echo "<tr>";
              echo "<td class = \"centar\">$uk_broj_slika</td>";
              echo "<td class = \"centar\">$uk_broj_jav_slika</td>";
              echo "<td class = \"centar\">$uk_broj_pri_slika</td>";
              echo "<td class = \"centar\">$post_jav_slika</td>";
              echo "<td class = \"centar\">$post_pri_slika</td>";
            echo "</tr>";
      echo "</tbody>";
    echo "</table>";

    echo "</div>";
  }

  echo "</section>";
  
  
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="autor" content="Borna Alvir">
    <meta name="datum" content="16.01.2022.">
    <link rel="stylesheet" type="text/css" href="CSS/Glavni.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <title>HR PLANINE</title>
  </head>
  <body>
    <?php
      zatvoriVezuNaBazu($veza);
      include ("prazni.php");
      include_once ("footer.php");
    ?>
  </body>
</html>