<?php

  session_start();

  include_once ("meni.php");
  include_once ("slika.php");
  include_once ("baza.php");
  include ("prazni.php");

  $veza = spojiSeNaBazu();

  echo "<section class = \"section_id11\">";

  echo "<h1>Editiranje korisnika</h1>";
  
  if (isset($_POST) && !empty($_POST)) {
    $pst_id_korisnika = "{$_POST["kor_id"]}";
    $pst_tip_korisnika = "{$_POST["kor_tip"]}";
    $pst_user_name_korisnika = "{$_POST["kor_username"]}";
    $pst_lozinka_korisnika = "{$_POST["kor_lozinka"]}";
    $pst_ime_korisnika = "{$_POST["korisnicko_ime"]}";
    $pst_prezime_korisnika = "{$_POST["kor_prezime"]}";
    $pst_email_korisnika = "{$_POST["kor_email"]}";
    $pst_status_korisnika = "{$_POST["kor_status"]}";
    $pst_slika_korisnika = "{$_POST["kor_slika"]}";
    $pst_delete = "{$_POST["delete"]}";

    $upit = "UPDATE `korisnik` SET 
    `korisnik_id` = '$pst_id_korisnika', 
    `tip_korisnika_id` = '$pst_tip_korisnika', 
    `korisnicko_ime` = '$pst_user_name_korisnika', 
    `lozinka` = '$pst_lozinka_korisnika', 
    `ime` = '$pst_ime_korisnika', 
    `prezime` = '$pst_prezime_korisnika', 
    `email` = '$pst_email_korisnika', 
    `blokiran` = '$pst_status_korisnika', 
    `slika` = '$pst_slika_korisnika'
    WHERE `korisnik`.`korisnik_id` = '$pst_id_korisnika'";

    izvrsiUpit($veza, $upit);

    if ($pst_delete == '1') {
      $upit = "DELETE FROM `slika` WHERE `slika`.`korisnik_id` = \"$pst_id_korisnika\"";
      izvrsiUpit($veza, $upit);
      $upit = "DELETE FROM `moderator` WHERE `moderator`.`korisnik_id` = \"$pst_id_korisnika\"";
      izvrsiUpit($veza, $upit);
      $upit = "DELETE FROM `korisnik` WHERE `korisnik`.`korisnik_id` = \"$pst_id_korisnika\"";
      izvrsiUpit($veza, $upit);
      echo "<p style='color:green'>Uspješno ste izbrisali korisnika: <b>\"$pst_user_name_korisnika\"</b></p>";
      echo "<a href = \"moj_profil.php?\"><input class=\"gumb\" type=\"submit\" value=\"Moj Profil\" /></a>";
      echo "<br>";

    }
    else {

    
    if ($pst_status_korisnika == '1') {
      $upit = "SELECT * FROM slika where korisnik_id = \"$pst_id_korisnika\" ";
      $rezultat_slika = izvrsiUpit($veza, $upit);
       while ($podaci_slika = mysqli_fetch_array($rezultat_slika)) {
        $upit = "UPDATE `slika` SET `status` = '0' WHERE `korisnik_id` = \"$pst_id_korisnika\"";
        izvrsiUpit($veza, $upit);
        echo "<p style='color:green'>Uspješno ste promijenili status slike $podaci_slika[0] u <b>privatnu fotografiju</b></p>";
      }
    }
    echo "<p style='color:green'>Uspješno ste promijenili podatke korisnika <b>\"$pst_user_name_korisnika\"</b></p>";
    echo "<a href = \"moj_profil.php?\"><input class=\"gumb\" type=\"submit\" value=\"Moj Profil\" /></a>";
    echo "<br>";
    }
  }

  if ($_SESSION["tip_korisnika"] == "0" && empty($_SERVER["QUERY_STRING"])) {
    echo "<div>";

    $upit = "SELECT * FROM `korisnik` ORDER BY `korisnik`.`korisnik_id` ASC";
    $rezultat_korisnici= izvrsiUpit($veza, $upit);

    echo "<Table>";
      echo "<thead>";
        echo "<tr>";
          echo "<th>ID KORISNIKA</th>";
          echo "<th>TIP KORISNIKA</th>";
          echo "<th>KORISNIČKO IME</th>";
          echo "<th>LOZINKA</th>";
          echo "<th>IME</th>";
          echo "<th>PREZIME</th>";
          echo "<th>EMAIL</th>";
          echo "<th>STATUS</th>";
          echo "<th>SLIKA</th>";
          echo "<th>AŽURIRAJ</th>";
        echo "</tr>";
      echo "</thead>";
      echo "<tbody>";
            while ($podatak_korisnici = mysqli_fetch_array($rezultat_korisnici)) {
            echo "<tr>";
              echo "<td class = \"centar\">{$podatak_korisnici[0]}</td>";
              if ($podatak_korisnici[1] == '0') {
              echo "<td>Admin</td>";
              }
              elseif ($podatak_korisnici[1] == '1') {
                echo "<td>Moderator</td>";
              }
              else {
                echo "<td>Korisnik</td>";
              }
              echo "<td>{$podatak_korisnici[2]}</td>";
              echo "<td>{$podatak_korisnici[3]}</td>";
              echo "<td>{$podatak_korisnici[4]}</td>";
              echo "<td>{$podatak_korisnici[5]}</td>";
              echo "<td>{$podatak_korisnici[6]}</td>";
              if ($podatak_korisnici[7] == '0') {
                echo "<td class = \"centar\">Nije blokiran</td>";
              }
              else {
                echo "<td class = \"centar\">BLOKIRAN</td>";
              }
              echo "<td><img border=0 alt=foi.hr src=\"{$podatak_korisnici[8]}\" width = 100px height = 100px></td>";
              echo "<td class = \"centar\"><a href = \"editiranje_korisnika.php?$podatak_korisnici[0]\"><input class=\"gumb\" type=\"submit\" value=\"Ažuriraj\" /></a></td>";
            echo "</tr>";
          }
      echo "</tbody>";
    echo "</table>";

    echo "</div>";
  }

  

  if ($_SESSION["tip_korisnika"] == "0" &&  !empty($_SERVER["QUERY_STRING"])) {

    $id_korisnika = $_SERVER["QUERY_STRING"];

    $upit = "SELECT * FROM korisnik where korisnik_id = \"$id_korisnika \"";
    $rezultat_korisnici= izvrsiUpit($veza, $upit);

    $podatak_korisnici = mysqli_fetch_array($rezultat_korisnici);
  
  echo "<form name=\"editiranje_korisnika_admin\" method=\"post\" action=\"{$_SERVER["PHP_SELF"]}\">";
    echo "<div>";
      echo "<label for=\"kor_id\">KORISNIK ID:</label>";
      echo "<input id=\"kor_id\" name=\"kor_id\" type=\"text\" value =\"$podatak_korisnici[0]\" readonly >";
    echo "</div>";
    echo "<div>";
      $upit = "SELECT * FROM tip_korisnika";
      $rezultat_tip= izvrsiUpit($veza, $upit);
      $upit = "SELECT * FROM tip_korisnika where tip_korisnika_id = \"$podatak_korisnici[1] \"";
      $rezultat_tip1= izvrsiUpit($veza, $upit);
      $podatak_korisnici1 = mysqli_fetch_array($rezultat_tip1);
      echo "<label for=\"kor_tip\">Sortiranje po nazivu</label>";
      echo "<select id=\"kor_tip\" name=\"kor_tip\">";
      echo "<option value = \"$podatak_korisnici1[0]\" selected hidden >$podatak_korisnici1[1]</option>";
        while($podaci_tip = mysqli_fetch_array($rezultat_tip)){
          echo "<option value='{$podaci_tip [0]}'";
          echo ">{$podaci_tip [1]}</option>";
        }
  echo "</select>";
  echo "</div>";
    echo "<div>";
      echo "<label for=\"kor_username\">KORISNICKO IME: </label>";
      echo "<input id=\"kor_username\" name=\"kor_username\" type=\"text\" value =\"$podatak_korisnici[2]\"/>";
    echo "</div>";
    echo "<div>";
      echo "<label for=\"kor_lozinka\">LOZINKA: </label>";
      echo "<input id=\"kor_lozinka\" name=\"kor_lozinka\" type=\"text\" value =\"$podatak_korisnici[3]\"/>";
    echo "</div>";
      echo "<div>";
      echo "<label for=\"kor_ime\">IME: </label>";
      echo "<input id=\"kor_ime\" name=\"korisnicko_ime\" type=\"text\" value =\"$podatak_korisnici[4]\"/>";
    echo "</div>";
    echo "<div>";
      echo "<label for=\"kor_prezime\">PREZIME: </label>";
      echo "<input id=\"kor_prezime\" name=\"kor_prezime\" type=\"text\" value =\"$podatak_korisnici[5]\"/>";
    echo "</div>";
    echo "<div>";
      echo "<label for=\"kor_email\">EMAIL: </label>";
      echo "<input id=\"kor_email\" name=\"kor_email\" type=\"text\" value =\"$podatak_korisnici[6]\"/>";
    echo "</div>";
    echo "<div>";
      echo "<label for=\"kor_status\">STATUS KORISNIKA: </label>";
      echo "<select id=\"kor_status\" name=\"kor_status\">";
      if ($podatak_korisnici[7] == '0') {
        $nije_blokiran = "Nije blokiran";
      echo "<option value = \"$podatak_korisnici[7]\" selected hidden>Nije blokiran</option>";
          echo "<option value='0'>Nije blokiran</option> ";
          echo "<option value='1'>Blokiran</option> ";
      }
      else {
        echo "<option value = \"$podatak_korisnici[7]\" selected hidden>Blokiran</option>";
          echo "<option value='0'>Nije blokiran</option> ";
          echo "<option value='1'>Blokiran</option> ";
      }
    echo "</select>";
    echo "</div>";
    echo "<div>";
      echo "<label for=\"kor_slika\">SLIKA: </label>";
      echo "<input id=\"kor_slika\" name=\"kor_slika\" type=\"text\" value =\"$podatak_korisnici[8]\"/>";
    echo "</div>";
    echo "<div>";
      echo "<label for=\"delete\">OBRISATI KORISNIKA?</label>";
      echo "<select id=\"delete\" name=\"delete\">";
      echo "<option value=\"1\">Da</option>";
      echo "<option value=\"0\"selected>Ne</option>";
      echo "</select>";
    echo "</div>";
    echo "<div>";
      echo "<input class=\"gumb\" type=\"submit\" value=\"Ažuriraj\" />";
    echo "</div>";
  echo "</form>";

  }

  echo "</section>";
  
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="autor" content="Borna Alvir">
    <meta name="datum" content="16.01.2022.">
    <link rel="stylesheet" type="text/css" href="CSS/Glavni.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <title>HR PLANINE</title>
  </head>
  <body>
    <?php
      zatvoriVezuNaBazu($veza);
      include ("prazni.php");
      include_once ("footer.php");
    ?>
  </body>
</html>