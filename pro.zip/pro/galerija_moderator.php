<?php

  session_start();

  include_once("meni.php");
  include_once ("slika.php");
  include_once ("baza.php");
  include ("prazni.php");

  $veza = spojiSeNaBazu();

  if (isset($_SERVER["QUERY_STRING"]) && !empty($_SERVER["QUERY_STRING"])) {

    $poh_get_planina_id = $_SERVER["QUERY_STRING"];
    
    $upit = "SELECT * FROM `slika` WHERE status = \"1\" AND planina_id = \"$poh_get_planina_id \" ORDER BY datum_vrijeme_slikanja DESC";
  }

  echo "<section class = \"section_id4\">";

  $rezultat = izvrsiUpit($veza, $upit);
    while ($podaci = mysqli_fetch_array($rezultat)) {
      echo "<div>";
      echo "<img border=\"0\"  alt=\"foi.hr\" src=\"$podaci[4]\" width=\"500px\" height=\"300px\"></a>";
      if (isset($_SESSION["tip_korisnika"]) && ($_SESSION["tip_korisnika"] == '1' || $_SESSION["tip_korisnika"] == '0')) {

        $upit = "SELECT * FROM korisnik";
        $rezultat_korisnik = izvrsiUpit($veza, $upit);

        while($podaci_korisnik = mysqli_fetch_array($rezultat_korisnik)){
          if ($podaci_korisnik[0] == $podaci[2]) {
            echo "<p><b>Ime:</b> $podaci_korisnik[4]</p>";
            echo "<p><b>Prezime:</b> <a href=\"javni_profil_moderator.php?planina_id=$podaci[1]&korisnik_id=$podaci[2]&slika_id=$podaci[0]&\">$podaci_korisnik[5]</a></p>";
          }
        }
      
      }
      echo "</div>";
    }
    
  echo "</section>";

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="autor" content="Borna Alvir">
  <meta name="datum" content="16.01.2022.">
  <link rel="stylesheet" type="text/css" href="CSS/Glavni.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
  <title>HR PLANINE</title>
</head>
<body>
  <?php
    zatvoriVezuNaBazu($veza);
    include ("prazni.php");
    include_once ("footer.php");
  ?>
</body>


</html>