<?php

  session_start();

  include_once ("meni.php");
  include_once ("slika.php");
  include_once ("baza.php");

  $veza = spojiSeNaBazu();

  if (isset($_POST["korisnicko_ime"]) && isset($_POST["lozinka"]) && !empty($_POST["korisnicko_ime"]) && !empty($_POST["lozinka"])) {
    $poruka_da = "";
    $poruka_da_prijava = "";
    $poruka_ne = "";
    $poruka_ne_prijava = "";

    $upit = "SELECT * FROM korisnik WHERE korisnicko_ime = \"{$_POST["korisnicko_ime"]}\" AND lozinka = \"{$_POST["lozinka"]}\"";

    $rezultat = izvrsiUpit($veza, $upit);

    $login = FALSE;

    while ($podaci = mysqli_fetch_array($rezultat)) {
      $login = TRUE;
      $_SESSION["korisnik_id"] = $podaci[0];
      $_SESSION["tip_korisnika"] = $podaci[1];
      $_SESSION["korisnicki_username"] = $podaci[2];
      $_SESSION["ime"] = $podaci[4];
      $_SESSION["prezime"] = $podaci[5];
      $_SESSION["email"] = $podaci[6];
      $_SESSION["blokiran_status"] = $podaci[7];
      $_SESSION["slika"] = $podaci[8];
    }

    if ($login) {
      $poruka_da .= "Uspješna prijava.";
      $poruka_da_prijava .= "Dobrodošao {$_POST["korisnicko_ime"]}!";
    }
    else {
      $poruka_ne_prijava .= "Neispravno korisničko ime i/ili lozinka!";
    }
    
  }
  else {
    $poruka_ne = "Niste upisali korisničko ime/ili lozinku!";
  }

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="autor" content="Borna Alvir">
  <meta name="datum" content="16.01.2022.">
  <link rel="stylesheet" type="text/css" href="CSS/Glavni.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
  <title>HR PLANINE</title>
</head>
  <body>

    <section class = "section_prazni"></section>

    <section class = "section_id2">
      <h1>Prijava</h1>
        <form name="registracija_korisnika" method="post" action=<?php "{$_SERVER["PHP_SELF"]}" ?>>  
          <div>
              <label for="kor_ime">Korisničko ime:</label>
              <input id="kor_ime" name="korisnicko_ime" type="text" />
          </div>
          <div>
            <label for="kor_lozinka">Lozinka:</label>
            <input id="kor_lozinka" name="lozinka" type="password" />
          </div>
          <div class="prazni"></div>
          <div>
            <input class="gumb" type="submit" value="Prijava" />
          </div>
          <div class="prazni"></div>
        </form>
    </section>

    <section class = "section_id2">
      <?php

        if(isset($poruka_da_prijava) && isset($poruka_da) && !empty($poruka_da_prijava) && !empty($poruka_da) && $_SERVER["REQUEST_METHOD"] == 'POST') {
          echo "<p>$poruka_da</p>";
          echo "<p>$poruka_da_prijava</p>";
          echo "<a href = \"moj_profil.php?\"><input class=\"gumb\" type=\"submit\" value=\"Moj Profil\" /></a>";
        }
        
        if(isset($poruka_ne_prijava) && !empty($poruka_ne_prijava) && $_SERVER["REQUEST_METHOD"] == 'POST') {
          echo "<p>$poruka_ne_prijava</p>";
        }

        if (isset($poruka_ne) && $_SERVER["REQUEST_METHOD"] == 'POST') {
          echo "<p>$poruka_ne</p>";
        }

      ?>
    </section>

    <?php

      zatvoriVezuNaBazu($veza);
      if ($_SERVER["REQUEST_METHOD"] == 'POST') {
        include("prazni.php");
      }
      include_once ("footer.php");

    ?>
  </body>
</html>