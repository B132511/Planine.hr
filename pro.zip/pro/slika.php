<section class = "section_id0">
  <div class = "section_id0_div_slika"></div>
</section>