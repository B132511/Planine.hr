<?php

  session_start();

  include_once("meni.php");
  include_once ("slika.php");
  include_once ("baza.php");
  include ("prazni.php");

  $veza = spojiSeNaBazu();

  if (empty($_SERVER["QUERY_STRING"]) && $_SERVER["REQUEST_METHOD"] == 'GET') {
    echo "<section class = \"section_id4_sortiranje\">";
    echo "<form name=\"sortiranje\" method=\"post\" action=\"{$_SERVER["PHP_SELF"]}\">";
    echo "<div>";
    $upit = "SELECT * FROM planina";
    $rezultat_planina = izvrsiUpit($veza, $upit);
    echo "<label for=\"sortiranje_po_nazivu\">Sortiranje po nazivu</label>";
    echo "<select id=\"sortiranje_po_nazivu\" name=\"sortiranje_po_nazivu\">";
    echo "<option value = \"\" selected hidden >Odaberite planinu</option>";
      while($podaci_planina = mysqli_fetch_array($rezultat_planina)){
        echo "<option value='{$podaci_planina [0]}'";
        echo ">{$podaci_planina [1]}</option>";
      }
    echo "</select>";
    echo "</div>";
    echo "<div>";
    echo "<label for=\"sortiranje_od_datuma\">Sortiranje OD datuma:</label>";
    echo "<input id=\"sortiranje_od_datuma\" name=\"sortiranje_od_datuma\" type=\"text\" maxlength = \"19\" placeholder=\"dd-mm-YYYY HH:ii:ss\" />";
    echo "</div>";
    echo "<div>";
    echo "<label for=\"sortiranje_do_datuma\">Sortiranje DO datuma:</label>";
    echo "<input id=\"sortiranje_do_datuma\" name=\"sortiranje_do_datuma\" type=\"text\" maxlength = \"19\" placeholder=\"dd-mm-YYYY HH:ii:ss\" />";
    echo "</div>";
    echo "<div>";
    echo "<input class=\"gumb\" type=\"submit\" value=\"Sortiraj\" />";
    echo "</div>";
    echo "</form>";
    echo "</section>";

    $upit ="SELECT * FROM `slika` WHERE status = \"1\" ORDER BY datum_vrijeme_slikanja DESC";
  }

  if ($_SERVER["REQUEST_METHOD"] == 'POST') {
    $poruka_greske_sortiranja = "";
    $go_sort_naziv = FALSE;
    $go_sort_od_datuma = FALSE;
    $go_sort_do_datuma = FALSE;
    $poh_sort_naziva = "{$_POST["sortiranje_po_nazivu"]}";
    $poh_sort_od_datuma = "{$_POST["sortiranje_od_datuma"]}";
    $poh_sort_do_datuma = "{$_POST["sortiranje_do_datuma"]}";

    if (isset($poh_sort_naziva) && !empty($poh_sort_naziva)) {
      $go_sort_naziv = TRUE;
      
    }

    if (isset($poh_sort_od_datuma) &&
      strlen($poh_sort_od_datuma) == '19' &&
      is_numeric(substr($poh_sort_od_datuma,0,2)) &&
      is_numeric(substr($poh_sort_od_datuma,3,2)) &&
      is_numeric(substr($poh_sort_od_datuma,6,4)) &&
      is_numeric(substr($poh_sort_od_datuma,11,2)) &&
      is_numeric(substr($poh_sort_od_datuma,14,2)) &&
      is_numeric(substr($poh_sort_od_datuma,17,2)) &&
      substr_count(substr($poh_sort_od_datuma,2,1),'-') == '1' &&
      substr_count(substr($poh_sort_od_datuma,5,1),'-') == '1' &&
      substr_count(substr($poh_sort_od_datuma,13,1),':') == '1' &&
      substr_count(substr($poh_sort_od_datuma,16,1),':') == '1' 
      ) {
      $go_sort_od_datuma = TRUE;

    } 

    if (isset($poh_sort_do_datuma) && 
      strlen($poh_sort_do_datuma) == '19' &&
      is_numeric(substr($poh_sort_do_datuma,0,2)) &&
      is_numeric(substr($poh_sort_do_datuma,3,2)) &&
      is_numeric(substr($poh_sort_do_datuma,6,4)) &&
      is_numeric(substr($poh_sort_do_datuma,11,2)) &&
      is_numeric(substr($poh_sort_do_datuma,14,2)) &&
      is_numeric(substr($poh_sort_do_datuma,17,2)) &&
      substr_count(substr($poh_sort_do_datuma,2,1),'-') == '1' &&
      substr_count(substr($poh_sort_do_datuma,5,1),'-') == '1' &&
      substr_count(substr($poh_sort_do_datuma,13,1),':') == '1' &&
      substr_count(substr($poh_sort_do_datuma,16,1),':') == '1' 
      ) {
      $go_sort_do_datuma = TRUE;

    } 
  
    if ($go_sort_naziv == FALSE && $go_sort_od_datuma == TRUE && $go_sort_do_datuma == FALSE) {
      $get_od_datuma_d =substr($poh_sort_od_datuma,0,2);
      $get_od_datuma_m =substr($poh_sort_od_datuma,3,2);
      $get_od_datuma_Y =substr($poh_sort_od_datuma,6,4);
      $get_od_datuma_H_i_s =substr($poh_sort_od_datuma,11,8);
      $novi_datum_za_bazu = $get_od_datuma_Y . "-" . $get_od_datuma_m . "-" . $get_od_datuma_d . " " . $get_od_datuma_H_i_s;

      $upit = "SELECT * FROM slika WHERE  datum_vrijeme_slikanja >= \"$novi_datum_za_bazu\" AND status = \"1\"  
      ORDER BY `slika`.`datum_vrijeme_slikanja` DESC";

    }

    if ($go_sort_naziv == FALSE && $go_sort_od_datuma == FALSE && $go_sort_do_datuma == TRUE) {
      $get_do_datuma_d =substr($poh_sort_do_datuma,0,2);
      $get_do_datuma_m =substr($poh_sort_do_datuma,3,2);
      $get_do_datuma_Y =substr($poh_sort_do_datuma,6,4);
      $get_do_datuma_H_i_s =substr($poh_sort_do_datuma,11,8);
      $novi_datum_za_bazu = $get_do_datuma_Y . "-" . $get_do_datuma_m . "-" . $get_do_datuma_d . " " . $get_do_datuma_H_i_s;

      $upit = "SELECT * FROM slika WHERE datum_vrijeme_slikanja <= \"$novi_datum_za_bazu\" AND status = \"1\"  
      ORDER BY `slika`.`datum_vrijeme_slikanja` DESC";
    }

    if ($go_sort_naziv == FALSE && $go_sort_od_datuma == TRUE && $go_sort_do_datuma == TRUE) {
      $get_od_datuma_d =substr($poh_sort_od_datuma,0,2);
      $get_od_datuma_m =substr($poh_sort_od_datuma,3,2);
      $get_od_datuma_Y =substr($poh_sort_od_datuma,6,4);
      $get_od_datuma_H_i_s =substr($poh_sort_od_datuma,11,8);
      $novi_datum_za_bazu_od = $get_od_datuma_Y . "-" . $get_od_datuma_m . "-" . $get_od_datuma_d . " " . $get_od_datuma_H_i_s;

      $get_do_datuma_d =substr($poh_sort_do_datuma,0,2);
      $get_do_datuma_m =substr($poh_sort_do_datuma,3,2);
      $get_do_datuma_Y =substr($poh_sort_do_datuma,6,4);
      $get_do_datuma_H_i_s =substr($poh_sort_do_datuma,11,8);
      $novi_datum_za_bazu_do = $get_do_datuma_Y . "-" . $get_do_datuma_m . "-" . $get_do_datuma_d . " " . $get_do_datuma_H_i_s;
    
      $upit = "SELECT * from slika where status = \"1\" and datum_vrijeme_slikanja >= \"$novi_datum_za_bazu_od\" and datum_vrijeme_slikanja <= \"$novi_datum_za_bazu_do\" ORDER BY `slika`.`datum_vrijeme_slikanja` DESC";
    }
    
    if ($go_sort_naziv == TRUE && $go_sort_od_datuma == TRUE && $go_sort_do_datuma == TRUE) {
      $get_od_datuma_d =substr($poh_sort_od_datuma,0,2);
      $get_od_datuma_m =substr($poh_sort_od_datuma,3,2);
      $get_od_datuma_Y =substr($poh_sort_od_datuma,6,4);
      $get_od_datuma_H_i_s =substr($poh_sort_od_datuma,11,8);
      $novi_datum_za_bazu_od = $get_od_datuma_Y . "-" . $get_od_datuma_m . "-" . $get_od_datuma_d . " " . $get_od_datuma_H_i_s;

      $get_do_datuma_d =substr($poh_sort_do_datuma,0,2);
      $get_do_datuma_m =substr($poh_sort_do_datuma,3,2);
      $get_do_datuma_Y =substr($poh_sort_do_datuma,6,4);
      $get_do_datuma_H_i_s =substr($poh_sort_do_datuma,11,8);
      $novi_datum_za_bazu_do = $get_do_datuma_Y . "-" . $get_do_datuma_m . "-" . $get_do_datuma_d . " " . $get_do_datuma_H_i_s;

      $upit = "SELECT * from slika where status = \"1\" and planina_id = \"$poh_sort_naziva\" and datum_vrijeme_slikanja >= \"$novi_datum_za_bazu_od\" and datum_vrijeme_slikanja <= \"$novi_datum_za_bazu_do\" ORDER BY `slika`.`datum_vrijeme_slikanja` DESC";
    }

    if ($go_sort_naziv == TRUE && $go_sort_od_datuma == FALSE && $go_sort_do_datuma == FALSE) {
      $upit = "SELECT * FROM `slika` where planina_id = \"$poh_sort_naziva\" AND status = \"1\"";
    }
    
    if ($go_sort_naziv == FALSE && $go_sort_od_datuma == FALSE && $go_sort_do_datuma == FALSE) {
      $upit ="SELECT * FROM `slika` WHERE status = \"1\" ORDER BY datum_vrijeme_slikanja DESC";
    }
    
  }

  if (isset($_SERVER["QUERY_STRING"]) && !empty($_SERVER["QUERY_STRING"])) {

    $poh_get_planina_id = $_SERVER["QUERY_STRING"];
    
    $upit = "SELECT * FROM `slika` WHERE status = \"1\" AND planina_id = \"$poh_get_planina_id \" ORDER BY datum_vrijeme_slikanja DESC";
  }

  $rezultat = izvrsiUpit($veza, $upit);

  echo "<section class = \"section_id4\">";
 
    while ($podaci = mysqli_fetch_array($rezultat)) {
      echo "<div>";
      echo "<a href=\"detaljne_info_o_slici.php?planina_id=$podaci[1]&korisnik_id=$podaci[2]&slika_id=$podaci[0]&\"><img border=\"0\"  alt=\"foi.hr\" src=\"$podaci[4]\" width=\"500px\" height=\"300px\"></a>";
      echo "</div>";
    }

  echo "</section>";

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="autor" content="Borna Alvir">
  <meta name="datum" content="16.01.2022.">
  <link rel="stylesheet" type="text/css" href="CSS/Glavni.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
  <title>HR PLANINE</title>
</head>
<body>
  <?php
    zatvoriVezuNaBazu($veza);
    include ("prazni.php");
    include_once ("footer.php");
  ?>
</body>


</html>