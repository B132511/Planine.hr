<?php

  session_start();
  
  include_once("baza.php");
  include_once("meni.php");
  include_once ("slika.php");
  include("prazni.php");

  $veza = spojiSeNaBazu();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
      <meta charset="utf-8">
      <meta name="autor" content="Borna Alvir">
      <meta name="datum" content="16.01.2022.">
      <link rel="stylesheet" type="text/css" href="CSS/Glavni.css">
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
      <title>HR PLANINE</title>
  </head>
  <body>
    <?php
      if (isset($_SESSION["tip_korisnika"]) && $_SESSION["tip_korisnika"] == '0' || $_SESSION["tip_korisnika"] == '1' || $_SESSION["tip_korisnika"] == '2' ) {
        echo "<section class = \"section_id5\">";
        echo "<h1>Postavljanje novih prava</h1>";
        echo "</section>";
        echo "<section class = \"section_id10\">";
        echo "<form name=\"registracija_moderatora\" method=\"post\" action= \"{$_SERVER["PHP_SELF"]}\">";

        echo "<div>";
        $upit = "SELECT * FROM korisnik where tip_korisnika_id = 1 OR tip_korisnika_id = 0";
        $rezultat_korisnici = izvrsiUpit($veza, $upit);
        echo "<label for=\"korisnici_id\">MODERATOR: </label>";
        echo "<select id=\"korisnici_id\" name=\"korisnici_id\">";
        echo "<option value = \"\" selected hidden >Odaberite moderatora</option>";
          while($podaci_korisnici = mysqli_fetch_array($rezultat_korisnici)){
            echo "<option value='{$podaci_korisnici[0]}'";
            echo ">{$podaci_korisnici[2]}</option>";
          }
        echo "</select>";
        echo "</div>";

        echo "<div>";
        $upit = "SELECT * FROM planina";
        $rezultat_planina = izvrsiUpit($veza, $upit);
        echo "<label for=\"planina_id\">NAZIV PLANINE: </label>";
        echo "<select id=\"planina_id\" name=\"planina_id\">";
        echo "<option value = \"\" selected hidden >Odaberite planinu</option>";
          while($podaci_planina = mysqli_fetch_array($rezultat_planina)){
            echo "<option value='{$podaci_planina[0]}'";
            echo ">{$podaci_planina[1]}</option>";
          }
        echo "</select>";
        echo "</div>";

        echo "<div>";
        echo "<input class=\"gumb\" type=\"submit\" value=\"Kreiraj\" />";  
        echo "</div>";
        echo "</form>";
        echo "</section>";
        
      }

      if ($_SERVER["REQUEST_METHOD"] == 'POST') {
        $poruka_greske_upisa = "";
        $poh_id_korisnika = "{$_POST["korisnici_id"]}";
        $poh_id_planine = "{$_POST["planina_id"]}";
      
        if (!isset($poh_id_korisnika) || empty($poh_id_korisnika)) {
          $poruka_greske_upisa .= "Niste odabrali moderatora!<br>";
        }

        if (!isset($poh_id_planine) || empty($poh_id_planine)) {
          $poruka_greske_upisa .= "Niste odabrali planinu!<br>";
        }

      }
      
      if (empty($poruka_greske_upisa) && $_SERVER["REQUEST_METHOD"] == 'POST') {
        
        $upit = "SELECT * FROM `moderator` where korisnik_id = \"$poh_id_korisnika\" AND planina_id = \"$poh_id_planine \"";

        $rezultat_test = izvrsiUpit($veza, $upit);

        $podaci_test = mysqli_fetch_array($rezultat_test);

        if ($podaci_test == NULL) {

          $poruka_uspjesnog_uplouda = "";

          $upit = "INSERT INTO `moderator` (`korisnik_id`, `planina_id`) VALUES ('$poh_id_korisnika', '$poh_id_planine ')";
      
          izvrsiUpit($veza, $upit);
      
          $id_nove_slike = mysqli_insert_id($veza);
      
          $poruka_uspjesnog_uplouda .= "<p style='color:green'>Uspješno ste postavili moderatora za planinu!</p>";
        
        }
        else {
          $poruka_greske_upisa .= "Pravilo za tog moderatora već postoji!";
        }
     
      }
        
      if (isset($poruka_greske_upisa) && $_SERVER["REQUEST_METHOD"] == 'POST') {
        echo "<section class = \"section_id10\">";
        echo "<br>";
        echo "$poruka_greske_upisa";
        echo "</section>";
      }

      if (isset($poruka_uspjesnog_uplouda) && $_SERVER["REQUEST_METHOD"] == 'POST') {
        echo "<section class = \"section_id10\">";
        echo "$poruka_uspjesnog_uplouda";
        echo "<a href = \"moj_profil.php?\"><input class=\"gumb\" type=\"submit\" value=\"Moj Profil\" /></a>";
        echo "</section>";
      }
      
      zatvoriVezuNaBazu($veza);
      include("prazni.php");
      include_once("footer.php");
    ?>
  </body>

</html>