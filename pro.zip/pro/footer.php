<footer>
    <div class = "footer_div_prazni_prvi"></div>
    <div><a class = "editirani" target = "_blank" href="https://foi.hr/">FAKULTET ORGANIZACIJE I INFORMATIKE</a></div>
    <div><a class = "editirani" target = "_blank" href="https://nastava.foi.hr/course/50979/2021-2022/VZ">IWA PROJEKT</a></div>
    <div><a class = "editirani" href="o_autoru.html">O AUTORU</a></div>
    <div class = "footer_div_prazni_zadnji"></div>
</footer>
