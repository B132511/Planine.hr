<?php

  session_start();

  include_once("baza.php");
  include_once("meni.php");
  include_once ("slika.php");
  include("prazni.php");

  $veza = spojiSeNaBazu();

?>

<!DOCTYPE html>
<html lang="en">
  <head>
      <meta charset="utf-8">
      <meta name="autor" content="Borna Alvir">
      <meta name="datum" content="16.01.2022.">
      <link rel="stylesheet" type="text/css" href="CSS/Glavni.css">
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
      <title>HR PLANINE</title>
  </head>
  <body>
  <?php
    echo "<section class=\"section_id5\">";
      
    if (isset($_SESSION["tip_korisnika"]) && ($_SESSION["tip_korisnika"] == '2' || $_SESSION["tip_korisnika"] == '1' ||  $_SESSION["tip_korisnika"] == '0')) {
      echo "<h1>Korisničke akcije</h1>";
      echo "<section class = \"section_id65\">";
      if ($_SESSION["blokiran_status"] == 0) {
      echo "<div>";
      echo "<p><a href=\"registracija_slike.php\"><input class=\"gumb\" type=\"submit\" value=\"Prijenos nove slike\"></a></p>";
      echo "</div>";
      }
      else {
        echo "<div>";
        echo "Ne postoje akcije kojima imate trenutno pristup.";
        echo "</div>";
      }
      
      if (($_SESSION["tip_korisnika"] == '1') || ($_SESSION["tip_korisnika"] == '0')) {
        echo "<div>";
        $upit = "SELECT m.planina_id, p.naziv FROM moderator AS m JOIN planina AS p ON m.planina_id = p.planina_id WHERE m.korisnik_id = \"{$_SESSION["korisnik_id"]}\"";
        $rezultat_moderator = izvrsiUpit($veza, $upit);
        while ($podatak_moderator_planina = mysqli_fetch_array($rezultat_moderator)){
          echo "<p><a href=\"galerija_moderator.php?$podatak_moderator_planina[0]\"><input class=\"gumb\" type=\"submit\" value=\"Moderiranje $podatak_moderator_planina[1]\"></a></p>";
        }
        echo "</div>";
      }

      if (($_SESSION["tip_korisnika"] == '0')) {
        echo "<div>";
        echo "<p><a href=\"registracija_korisnika.php\"><input class=\"gumb\" type=\"submit\" value=\"Registracija novog korisnika\"></a></p>";
        echo "</div>";
        echo "<div>";
        echo "<p><a href=\"editiranje_korisnika.php\"><input class=\"gumb\" type=\"submit\" value=\"Pregled korisnika\"></a></p>";
        echo "</div>";
        echo "<div>";
        echo "<p><a href=\"registracija_moderatora.php\"><input class=\"gumb\" type=\"submit\" value=\"Postavljanje novih moderacijskih pravila\"></a></p>";
        echo "</div>";
        echo "<div>";
        echo "<p><a href=\"editiranje_moderatora.php\"><input class=\"gumb\" type=\"submit\" value=\"Pregled moderacijski pravila\"></a></p>";
        echo "</div>";
        echo "<div>";
        echo "<p><a href=\"registracija_planine.php\"><input class=\"gumb\" type=\"submit\" value=\"Dodavanje novih planina\"></a></p>";
        echo "</div>";
        echo "<div>";
        echo "<p><a href=\"editiranje_planina.php\"><input class=\"gumb\" type=\"submit\" value=\"Pregled planina\"></a></p>";
        echo "</div>";
        echo "<div>";
        echo "<p><a href=\"statistika_baze.php\"><input class=\"gumb\" type=\"submit\" value=\"Statistika\"></a></p>";
        echo "</div>";
      }
      echo "</section>";
    }

    echo "<h1>Moji podaci</h1>";
    echo "<section class = \"section_id992\">";
    if (isset($_SESSION) && !empty($_SESSION)){
      echo "<div class = \"div_id982\">";
      echo "<div>";
      echo "<img border=0 alt=foi.hr src={$_SESSION["slika"]} width=150px height=200px>";
      echo "</div>";
      echo "</div>";
      echo "<div class = \"div_id992\">";
      echo "<div>";
      if ($_SESSION["blokiran_status"] == 0) {
      echo "<b>Ime:</b> {$_SESSION["ime"]}";
      echo "</div>";
      echo "<div>";
      echo "<b>Prezime:</b> {$_SESSION["prezime"]}";
      echo "</div>";
      echo "<div>";
      echo "<b>Korisničko ime:</b> {$_SESSION["korisnicki_username"]}";
      echo "</div>";
      echo "<div>";
      echo "<b>Email:</b> {$_SESSION["email"]}";
      echo "</div>";
      echo "<div>";
      echo "<b>Status korisnika:</b> ";
      if ($_SESSION["tip_korisnika"] == 0) {
        echo "Admin";
      }
      elseif ($_SESSION["tip_korisnika"] == 1) {
        echo "Moderator";
      }
      else {
        echo "Korisnik";
      }
      }
      else {
        echo "<div>";
        echo "<p style='color:red'> Trenutno imate zabranjeni pristup sustavu.</p>"; 
        echo "<p>Ako smatrate da je to greška kontaktirajte administratora.";
        echo "</div>";
      }
      echo "</div>";
      echo "</div>";
      echo "</section>";
    }

    if (isset($_SESSION["korisnik_id"]) && !empty($_SESSION["korisnik_id"])) {

      echo "<h1>Moje slike</h1>";
      echo "<section class = \"section_id6\">";

      $upit = "SELECT * FROM slika WHERE korisnik_id = \"{$_SESSION["korisnik_id"]}\"";
      $rezulat = izvrsiUpit($veza, $upit);

      while ($podaci = mysqli_fetch_array($rezulat)) {
        if ($_SESSION["blokiran_status"] == 0) {
        echo "<div>";
        echo "<img border=\"0\" alt=\"foi.hr\" src=\"$podaci[4]\" width=\"250px\" height=\"150px\">";
        echo "<p><b>Naziv slike:</b> $podaci[3]</p>";
        echo "<p><b>Opis slike:</b> $podaci[5]</p>";
        echo "<p>";
        echo "<b>Status:</b> ";
        if ($podaci[7] == 1){
          echo "Javna slika";
        }
        else {
          echo "Privatna slika";
        }
        echo "</p>";
        echo "<p>";
        echo "<a href = \"editiranje_slike.php?planina_id=$podaci[1]&korisnik_id=$podaci[2]&slika_id=$podaci[0]\"><input class=\"gumb\" type=\"submit\" value=\"Ažuriranje podataka\" /></a>";
        echo "</p>";
        echo "</div>";
        }
        else {
          echo "<div>";
          echo "<p>Sve Vaše slike trenutno su privatne i nisu vidljive ostalim korisnicima";
          echo "</div>";
        }
      }

      echo "</section>";
    }
          
    echo "</section>";
    
    zatvoriVezuNaBazu($veza);
    include("prazni.php");
    include_once("footer.php");
    ?>
  </body>

</html>