<?php

  session_start();

  include_once ("meni.php");
  include_once ("slika.php");
  include_once ("baza.php");
  include ("prazni.php");

  $veza = spojiSeNaBazu();

  echo "<section class = \"section_id11\">";

  echo "<h1>Editiranje pravila moderatora</h1>";

  if (isset($_POST) && !empty($_POST)) {
    $pst_id_korisnika_promjena = "{$_POST["kor_id_pro"]}";
    $pst_id_planine_promjena = "{$_POST["pla_naziv_pro"]}";
    $pst_id_korisnika = "{$_POST["kor_id"]}";
    $pst_id_planine = "{$_POST["pla_id"]}";
    $pst_delete = "{$_POST["delete"]}";

    if ($pst_delete == '1') {
      $upit = "DELETE FROM `moderator` WHERE `moderator`.`korisnik_id` = \"$pst_id_korisnika\" AND `moderator`.`planina_id` = \"$pst_id_planine\"";
      izvrsiUpit($veza, $upit);

      echo "<p style='color:green'>Uspješno ste izbisali prava moderatora <b>\"$pst_id_korisnika\"</b></p>";
      echo "<a href = \"moj_profil.php?\"><input class=\"gumb\" type=\"submit\" value=\"Moj Profil\" /></a>";
      echo "<br>";
    }
    else {

    $upit = "UPDATE `moderator` SET `korisnik_id` = '$pst_id_korisnika_promjena', `planina_id` = '$pst_id_planine_promjena' WHERE `moderator`.`korisnik_id` = \"$pst_id_korisnika\" AND `moderator`.`planina_id` = \"$pst_id_planine\"";

    izvrsiUpit($veza, $upit);

    echo "<p style='color:green'>Uspješno ste promijenili prava moderatora!</b></p>";
    echo "<a href = \"moj_profil.php?\"><input class=\"gumb\" type=\"submit\" value=\"Moj Profil\" /></a>";
    echo "<br>";
    }
    
  }

  if ($_SESSION["tip_korisnika"] == "0" && empty($_SERVER["QUERY_STRING"])) {
    echo "<div>";

    $upit = "SELECT
    k.korisnik_id  as `korisnik_id`,
    k.korisnicko_ime     as `korisnik_username`,
    p.planina_id     as `planina_id`,
    p.naziv  as `planina_naziv`
    FROM moderator AS `m`
      LEFT JOIN korisnik AS `k` ON (m.korisnik_id = k.korisnik_id)
      LEFT JOIN planina AS `p` ON (m.planina_id = p.planina_id)
    ORDER BY `k`.`korisnik_id` ASC";

    $rezultat_upita= izvrsiUpit($veza, $upit);

    echo "<Table>";
      echo "<thead>";
        echo "<tr>";
          echo "<th>MODERATOR ID</th>";
          echo "<th>MODERATOR</th>";
          echo "<th>PLANINA ID</th>";
          echo "<th>NAZIV PLANINE</th>";
          echo "<th>AŽURIRAJ</th>";
        echo "</tr>";
      echo "</thead>";
      echo "<tbody>";
            while ($podatak = mysqli_fetch_array($rezultat_upita)) {
            echo "<tr>";
              echo "<td class = \"centar\">{$podatak[0]}</td>";
              echo "<td>{$podatak[1]}</td>";
              echo "<td class = \"centar\">{$podatak[2]}</td>";
              echo "<td>{$podatak[3]}</td>";
              echo "<td class = \"centar\"><a href = \"editiranje_moderatora.php?$podatak[0]&$podatak[2]\"><input class=\"gumb\" type=\"submit\" value=\"Ažuriraj\" /></a></td>";
            echo "</tr>";
            }
      echo "</tbody>";
    echo "</table>";

    echo "</div>";
  }

 

  if ($_SESSION["tip_korisnika"] == "0" &&  !empty($_SERVER["QUERY_STRING"])) {

    $id_mod_pla = $_SERVER["QUERY_STRING"];

    $svi_idovi = explode("&",$id_mod_pla);

    $id_moderatora = $svi_idovi[0];
    $id_planine = $svi_idovi[1];

  echo "<form name=\"editiranje_moderatora_admin\" method=\"post\" action=\"{$_SERVER["PHP_SELF"]}\">";
    echo "<div>";
      $upit = "SELECT * FROM korisnik where korisnik_id = \"$id_moderatora\"";
      $rezultat_korisnika = izvrsiUpit($veza, $upit);
      $podatak_korisnik = mysqli_fetch_array($rezultat_korisnika);
      $upit = "SELECT * FROM korisnik where tip_korisnika_id = 1 OR tip_korisnika_id = 0";
      $rezultat_korisnici1= izvrsiUpit($veza, $upit);
      echo "<label for=\"kor_id_pro\">MODERATOR KORISNICKO IME:</label>";
      echo "<select id=\"kor_id_pro\" name=\"kor_id_pro\">";
      echo "<option value = \"$podatak_korisnik[0]\" selected hidden >$podatak_korisnik[2]</option>";
        while($podatak_korisnici1 = mysqli_fetch_array($rezultat_korisnici1)){
          echo "<option value='{$podatak_korisnici1[0]}'";
          echo ">{$podatak_korisnici1[2]}</option>";
        }
       echo "</select>";
    echo "</div>";
    echo "<div>";
      $upit = "SELECT * FROM planina where planina_id = \"$id_planine\"";
      $rezultat_planina = izvrsiUpit($veza, $upit);
      $podatak_planina= mysqli_fetch_array($rezultat_planina);
      $upit = "SELECT * FROM planina";
      $rezultat_planine= izvrsiUpit($veza, $upit);
      echo "<label for=\"pla_naziv_pro\">NAZIV PLANINE: </label>";
      echo "<select id=\"pla_naziv_pro\" name=\"pla_naziv_pro\">";
      echo "<option value = \"$podatak_planina[0]\" selected hidden >$podatak_planina[1]</option>";
      while($podaci_planine = mysqli_fetch_array($rezultat_planine)){
        echo "<option value='{$podaci_planine[0]}'";
        echo ">{$podaci_planine[1]}</option>";
      }
    echo "</select>";
    echo "</div>";
    echo "<div>";
      echo "<label for=\"delete\">OBRISATI PRAVILO?</label>";
      echo "<select id=\"delete\" name=\"delete\">";
      echo "<option value=\"1\">Da</option>";
      echo "<option value=\"0\"selected>Ne</option>";
    echo "</div>";
    echo "<div>";
      echo "<label hidden for=\"kor_id\"></label>";
      echo "<input id=\"kor_id\" name=\"kor_id\" type=\"text\" value =\"$id_moderatora\" hidden>";
    echo "</div>";
    echo "<div>";
      echo "<label hidden for=\"pla_id\"></label>";
      echo "<input id=\"pla_id\" name=\"pla_id\" type=\"text\" value =\"$id_planine\" hidden/>";
    echo "</div>";
      echo "<input class=\"gumb\" type=\"submit\" value=\"Ažuriraj\" />";
    echo "</div>";
  echo "</form>";

  }

  echo "</section>";

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="autor" content="Borna Alvir">
    <meta name="datum" content="16.01.2022.">
    <link rel="stylesheet" type="text/css" href="CSS/Glavni.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <title>HR PLANINE</title>
  </head>
  <body>
    <?php
      zatvoriVezuNaBazu($veza);
      include ("prazni.php");
      include_once ("footer.php");
    ?>
  </body>
</html>