<?php

  session_start();

  include_once ("meni.php");
  include_once ("slika.php");
  include_once ("baza.php");
  include ("prazni.php");

  $veza = spojiSeNaBazu();

  echo "<section class = \"section_id11\">";

  echo "<h1>Editiranje planina</h1>";

  if (isset($_POST) && !empty($_POST)) {
    $pst_id_planine = "{$_POST["pla_id"]}";
    $pst_naziv_planine = "{$_POST["pla_naziv"]}";
    $pst_opis_planine = "{$_POST["pla_opis"]}";
    $pst_lokacija_planine = "{$_POST["pla_lokacija"]}";
    $pst_geos_planine = "{$_POST["pla_geos"]}";
    $pst_geod_planine = "{$_POST["pla_geod"]}";
    $pst_delete = "{$_POST["delete"]}";

    if ($pst_delete == '1') {

      $upit = "DELETE FROM `slika` WHERE  `slika`.`planina_id` = \"$pst_id_planine\"";
      izvrsiUpit($veza, $upit);
      $upit = "DELETE FROM `moderator` WHERE  `moderator`.`planina_id` = \"$pst_id_planine\"";
      izvrsiUpit($veza, $upit);
      $upit = "DELETE FROM `planina` WHERE `planina`.`planina_id` = \"$pst_id_planine\"";
      izvrsiUpit($veza, $upit);

      echo "<p style='color:green'>Uspješno ste izbisali planinu <b>\"$pst_naziv_planine\"</b></p>";
      echo "<a href = \"moj_profil.php?\"><input class=\"gumb\" type=\"submit\" value=\"Moj Profil\" /></a>";
    }
    else {

    $upit = "UPDATE `planina` SET 
    `planina_id` = '$pst_id_planine', 
    `naziv` = '$pst_naziv_planine', 
    `opis` = '$pst_opis_planine',
    `lokacija` = '$pst_lokacija_planine',
    `geografska_sirina` = '$pst_geos_planine',
    `geografska_duzina` = '$pst_geod_planine'
    WHERE `planina`.`planina_id` = '$pst_id_planine'";

    izvrsiUpit($veza, $upit);

    echo "<p style='color:green'>Uspješno ste promijenili podatke planine <b>\"$pst_naziv_planine\"</b></p>";
    echo "<a href = \"moj_profil.php?\"><input class=\"gumb\" type=\"submit\" value=\"Moj Profil\" /></a>";
    }
    
  }

  if ($_SESSION["tip_korisnika"] == "0" && empty($_SERVER["QUERY_STRING"])) {
    echo "<div>";

    $upit = "SELECT * FROM planina";
    $rezultat_planina= izvrsiUpit($veza, $upit);

    echo "<Table>";
      echo "<thead>";
        echo "<tr>";
          echo "<th>ID PLANINE</th>";
          echo "<th>NAZIV PLANINE</th>";
          echo "<th>OPIS</th>";
          echo "<th>LOKACIJA</th>";
          echo "<th>GEOGRAFSKA ŠIRINA</th>";
          echo "<th>GEOGRAFSKA DUŽINA</th>";
          echo "<th>AŽURIRAJ</th>";
        echo "</tr>";
      echo "</thead>";
      echo "<tbody>";
            while ($podatak_planina = mysqli_fetch_array($rezultat_planina)) {
            echo "<tr>";
              echo "<td class = \"centar\">{$podatak_planina[0]}</td>";
              echo "<td class = \"centar\">{$podatak_planina[1]}</td>";
              echo "<td>{$podatak_planina[2]}</td>";
              echo "<td>{$podatak_planina[3]}</td>";
              echo "<td>{$podatak_planina[4]}</td>";
              echo "<td>{$podatak_planina[5]}</td>";
              echo "<td class = \"centar\"><a href = \"editiranje_planina.php?$podatak_planina[0]\"><input class=\"gumb\" type=\"submit\" value=\"Ažuriraj\" /></a></td>";
            echo "</tr>";
          }
      echo "</tbody>";
    echo "</table>";

    echo "</div>";
  }

  

  if ($_SESSION["tip_korisnika"] == "0" && !empty($_SERVER["QUERY_STRING"])) {

    $id_planina = $_SERVER["QUERY_STRING"];

    $upit = "SELECT * FROM planina where planina_id = \"$id_planina \"";
    $rezultat_planina = izvrsiUpit($veza, $upit);

    $podatak_planina = mysqli_fetch_array($rezultat_planina);
  
  echo "<form name=\"editiranje_korisnika_admin\" method=\"post\" action=\"{$_SERVER["PHP_SELF"]}\">";

    echo "<div>";
      echo "<label for=\"pla_id\">PLANINA ID:</label>";
      echo "<input id=\"pla_id\" name=\"pla_id\" type=\"text\" value =\"$podatak_planina[0]\" readonly >";
    echo "</div>";
    echo "<div>";
      echo "<label for=\"pla_naziv\">NAZIV PLANINE: </label>";
      echo "<input id=\"pla_naziv\" name=\"pla_naziv\" type=\"text\" value =\"$podatak_planina[1]\"/>";
    echo "</div>";
    echo "<div>";
      echo "<label for=\"pla_opis\">OPIS: </label>";
      echo "<input id=\"pla_opis\" name=\"pla_opis\" type=\"text\" value =\"$podatak_planina[2]\"/>";
    echo "</div>";
      echo "<div>";
      echo "<label for=\"pla_lokacija\">LOKACIJA: </label>";
      echo "<input id=\"pla_lokacija\" name=\"pla_lokacija\" type=\"text\" value =\"$podatak_planina[3]\"/>";
    echo "</div>";
    echo "<div>";
      echo "<label for=\"pla_geos\">GEOGRAFSKA ŠIRINA: </label>";
      echo "<input id=\"pla_geos\" name=\"pla_geos\" type=\"text\" value =\"$podatak_planina[4]\"/>";
    echo "</div>";
    echo "<div>";
      echo "<label for=\"pla_geod\">GEOGRAFSKA DUŽINA: </label>";
      echo "<input id=\"pla_geod\" name=\"pla_geod\" type=\"text\" value =\"$podatak_planina[5]\"/>";
    echo "</div>";
    echo "<div class = \"seronja\">";
      echo "<label for=\"delete\">OBRISATI PLANINU?</label>";
      echo "<select id=\"delete\" name=\"delete\">";
      echo "<option value=\"1\">Da</option>";
      echo "<option value=\"0\"selected>Ne</option>";
      echo "</select>";
    echo "</div>";
      echo "<input class=\"gumb\" type=\"submit\" value=\"Ažuriraj\" />";
    echo "</div>";
  echo "</form>";

  }

  echo "</section>";
  
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="autor" content="Borna Alvir">
    <meta name="datum" content="16.01.2022.">
    <link rel="stylesheet" type="text/css" href="CSS/Glavni.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <title>HR PLANINE</title>
  </head>
  <body>
    <?php
      zatvoriVezuNaBazu($veza);
      include ("prazni.php");
      include_once ("footer.php");
    ?>
  </body>
</html>