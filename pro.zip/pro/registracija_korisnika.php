<?php

  session_start();

  include_once ("meni.php");
  include_once ("slika.php");
  include_once ("baza.php");

  $veza = spojiSeNaBazu();

  $upit = "SELECT * FROM korisnik";

  $rezultat = izvrsiUpit($veza, $upit);

  if ($_SERVER["REQUEST_METHOD"] == 'POST') {
    $poruka_greske_upisa = "";
    $poh_ime = "{$_POST["korisnicko_ime"]}";
    $poh_prezime = "{$_POST["korisnicko_prezime"]}";
    $poh_email = "{$_POST["korisnicki_email"]}";
    $poh_id = "{$_POST["korisnicki_id"]}";
    $poh_lozinka = "{$_POST["korisnicka_lozinka"]}";
    $poh_slika = "{$_POST["korisnicka_slika"]}";

    if (!isset($poh_ime) || empty($poh_ime)) {
      $poruka_greske_upisa .= "Niste unijeli ime korisnika!";
    }
    if (!isset($poh_prezime) || empty($poh_prezime)) {
      $poruka_greske_upisa .= "Niste unijeli prezime korisnika!";
    }
    if (!isset($poh_email) || empty($poh_email)) {
      $poruka_greske_upisa .= "Niste unijeli email korisnika!";
    }
    if (!isset($poh_id) || empty($poh_id)) {
      $poruka_greske_upisa .= "Niste unijeli korisničko ime korisnika!";
    }
    if (!isset($poh_lozinka) || empty($poh_lozinka)) {
      $poruka_greske_upisa .= "Niste unijeli lozinku korisnika!";
    }
    
  }

  if (empty($poruka_greske_upisa) && $_SERVER["REQUEST_METHOD"] == 'POST') {
    $poruka_uspjesne_registracije = "";
    $poruka_uspjesne_registracije_korisnika = "";
    $upit = "INSERT INTO korisnik (tip_korisnika_id, korisnicko_ime, lozinka, ime, prezime, email, blokiran, slika) VALUES (2, '{$poh_id}', '{$poh_lozinka}', '{$poh_ime}', '{$poh_prezime}', '{$poh_email}', 0, '{$poh_slika}')";

    izvrsiUpit($veza, $upit);

    $id_novi_korisnik = mysqli_insert_id($veza);

    $poruka_uspjesne_registracije .= "<p style='color:green'>Uspješno ste se registirali novog člana!</p>";
    $poruka_uspjesne_registracije_korisnika .=  "ID novog korisnika je: <b>$id_novi_korisnik</b>";

  }
  
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="autor" content="Borna Alvir">
  <meta name="datum" content="16.01.2022.">
  <link rel="stylesheet" type="text/css" href="CSS/Glavni.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
  <title>HR PLANINE</title>
</head>

<body>

  <section class = "section_prazni"></section>

  <section class = "section_id3">
    <h1>Registracija novog korisnika</h1>
    <div>
      <form name="registracija_korisnika" method="post" action="<?php "{$_SERVER["PHP_SELF"]}" ?>">
        <div>       
          <label for="kor_ime">Ime:</label>
          <input id="kor_ime" name="korisnicko_ime" type="text" />
        </div>
        <div> 
          <label for="kor_prezime">Prezime:</label>
          <input id="kor_prezime" name="korisnicko_prezime" type="text" />
        </div>    
        <div> 
          <label for="kor_email">Email Adressa:</label>
          <input id="kor_email" name="korisnicki_email" type="email" />
        </div>
        <div> 
          <label for="kor_id">Korisničko ime:</label>
          <input id="kor_id" name="korisnicki_id" type="text" />
        </div>
        <div> 
          <label for="kor_lozinka">Lozinka:</label>
          <input id="kor_lozinka" name="korisnicka_lozinka" type="password" />
        </div>
        <div> 
          <label for="kor_slika">Slika:</label>
          <input id="kor_slika" name="korisnicka_slika" type="text" value="korisnici/" />
        </div>
        <div class="prazni"></div>
          <input class="gumb" type="submit" value="Unesi" />
          <input class="gumb" type="reset" value="Reset" />
        <div class="prazni"></div>
      </form>
    </div>
  </section>

  <section class = "section_id3">
    <?php

      if (isset($poruka_greske_upisa) && $_SERVER["REQUEST_METHOD"] == 'POST') {
        echo "$poruka_greske_upisa";
      }

      if (isset($poruka_uspjesne_registracije) && isset($poruka_uspjesne_registracije_korisnika) && $_SERVER["REQUEST_METHOD"] == 'POST') {
        echo "$poruka_uspjesne_registracije";
        echo "$poruka_uspjesne_registracije_korisnika";
      }

    ?>
  </section>
  <?php
    zatvoriVezuNaBazu($veza);
    include_once ("footer.php");
  ?>
</body>


</html>