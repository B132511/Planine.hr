<?php

  session_start();

  include_once ("meni.php");
  include_once ("slika.php");
  include_once ("baza.php");

  if (isset($_SESSION) && !empty($_SESSION)) {

    header ("refresh:2; url=index.php"); 

    $poruka_da_odjava = "";
    
    $temp_poh_ime = "{$_SESSION["ime"]}";
    
    session_destroy();
    
    $poruka_da_odjava .= "Uspješna odjava korisnika $temp_poh_ime.";

  }
  else {
    header ("refresh:0; url=index.php"); 
  }
    
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="autor" content="Borna Alvir">
  <meta name="datum" content="16.01.2022.">
  <link rel="stylesheet" type="text/css" href="CSS/Glavni.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
  <title>HR PLANINE</title>
</head>
  <body>

    <section class = "section_prazni"></section>

    <section class = "section_id5">
      <?php
        
        if(isset($poruka_da_odjava) && isset($_SESSION)) {
            echo "<h1>ODJAVA</h1>";
            echo "<p>$poruka_da_odjava</p>";
        }

      ?>
    </section>

    <section class = "section_prazni"></section>

    <?php

      include_once ("footer.php");

    ?>
  </body>
</html>