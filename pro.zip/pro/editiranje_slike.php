<?php

  session_start();
  
  include_once("baza.php");
  include_once("meni.php");
  include_once ("slika.php");
  include("prazni.php");

  $veza = spojiSeNaBazu();

  $poruka_greske_upisa = "";
  $provjera_datuma = "";

  if ($_SERVER["REQUEST_METHOD"] == 'POST') {
    $poh_planina_id = "{$_POST["pla_id"]}";
    $poh_slika_ime = "{$_POST["slika_ime"]}";
    $poh_slika_url= "{$_POST["slika_url"]}";
    $poh_slika_opis = "{$_POST["slika_opis"]}";
    $poh_slika_vrijeme = "{$_POST["slika_vrijeme"]}";
    $poh_slika_status = "{$_POST["slika_status"]}";
    $poh_slika_id = "{$_POST["slika_id"]}";
    $pst_delete = "{$_POST["delete"]}";

    $provjera_datuma = $poh_slika_vrijeme;

    if (!isset($poh_planina_id) || empty($poh_planina_id)) {
      $poruka_greske_upisa .= "Niste unijeli naziv planine! <br>";
    }

    if (!isset($poh_slika_ime) || empty($poh_slika_ime)) {
      $poruka_greske_upisa .= "Niste unijeli ime slike! <br>";
    }

    if (!isset($poh_slika_url) || empty($poh_slika_url)) {
      $poruka_greske_upisa .= "Niste unijeli URL slike! <br>";
    }

    if (!isset($poh_slika_opis) || empty($poh_slika_opis)) {
      $poruka_greske_upisa .= "Niste unijeli opis slike! <br>";
    }

    if (!isset($poh_slika_vrijeme) || empty($poh_slika_vrijeme)) {
      $poruka_greske_upisa .= "Niste unijeli vrijeme slike! <br>";
    }

    if (
    !strlen($provjera_datuma) == '19' ||
    !is_numeric(substr($provjera_datuma,0,2)) ||
    !is_numeric(substr($provjera_datuma,3,2)) ||
    !is_numeric(substr($provjera_datuma,6,4)) ||
    !is_numeric(substr($provjera_datuma,11,2)) ||
    !is_numeric(substr($provjera_datuma,14,2)) ||
    !is_numeric(substr($provjera_datuma,17,2)) ||
    !substr_count(substr($provjera_datuma,2,1),'-') == '1' ||
    !substr_count(substr($provjera_datuma,5,1),'-') == '1' ||
    !substr_count(substr($provjera_datuma,13,1),':') == '1' ||
    !substr_count(substr($provjera_datuma,16,1),':') == '1'
    ) {
      $poruka_greske_upisa .= "Niste unijeli ispravno vrijeme slike! <br>";

    }
    
  }

  if (isset($poruka_greske_upisa) && !empty($poruka_greske_upisa) && $_SERVER["REQUEST_METHOD"] == 'POST') {
    echo "<section class = \"section_id10\">";
    echo "$poruka_greske_upisa";
    echo "<a href = \"moj_profil.php?\"><input class=\"gumb\" type=\"submit\" value=\"Moj Profil\" /></a>";
    echo "<br>";
    echo "</section>";
  }

  if (empty($poruka_greske_upisa) && $_SERVER["REQUEST_METHOD"] == 'POST') {

    if ($pst_delete == '1') {
      $upit = "DELETE FROM `slika` WHERE `slika`.`slika_id` = \"$poh_slika_id\"";
      izvrsiUpit($veza, $upit);
      echo "<section class = \"section_id10\">";
      echo "<p style='color:green'>Uspješno ste izbrisali sliku: <b>\"$poh_slika_ime\"</b></p>";
      echo "<a href = \"moj_profil.php?\"><input class=\"gumb\" type=\"submit\" value=\"Moj Profil\" /></a>";
      echo "<br>";
      echo "</section>";
    }
    else {

    $get_od_datuma_d =substr($poh_slika_vrijeme,0,2);
    $get_od_datuma_m =substr($poh_slika_vrijeme,3,2);
    $get_od_datuma_Y =substr($poh_slika_vrijeme,6,4);
    $get_od_datuma_H_i_s =substr($poh_slika_vrijeme,11,8);
    $novi_datum_za_bazu1 = $get_od_datuma_Y . "-" . $get_od_datuma_m . "-" . $get_od_datuma_d . " " . $get_od_datuma_H_i_s;

    $poruka_uspjesnog_uplouda = "";

    $upit = "UPDATE `slika` SET 
    `planina_id` = '$poh_planina_id', 
    `naziv` = '$poh_slika_ime', 
    `url` = '$poh_slika_url',
    `opis` = '$poh_slika_opis',
    `datum_vrijeme_slikanja` = '$novi_datum_za_bazu1',
    `status` = '$poh_slika_status'
    WHERE `slika`.`slika_id` = '$poh_slika_id'";

    izvrsiUpit($veza, $upit);
    $poruka_uspjesnog_uplouda .= "Uspješno ste ažurirali podatke za sliku!";
    }

  }

  if (isset($poruka_uspjesnog_uplouda)  && $_SERVER["REQUEST_METHOD"] == 'POST') {
    echo "<section class = \"section_id10\">";
    echo "$poruka_uspjesnog_uplouda";
    echo "<br>";
    echo "<a href = \"moj_profil.php?\"><input class=\"gumb\" type=\"submit\" value=\"Moj Profil\" /></a>"; 
    echo "</section>";
  }

?>

<!DOCTYPE html>
<html lang="en">
  <head>
      <meta charset="utf-8">
      <meta name="autor" content="Borna Alvir">
      <meta name="datum" content="16.01.2022.">
      <link rel="stylesheet" type="text/css" href="CSS/Glavni.css">
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
      <title>HR PLANINE</title>
  </head>
  <body>
    <?php

      if ($_SERVER['REQUEST_METHOD'] == 'GET' && !empty($_SERVER['QUERY_STRING']) && isset($_SESSION["tip_korisnika"]) && ($_SESSION["tip_korisnika"] == '0' || $_SESSION["tip_korisnika"] == '1' || $_SESSION["tip_korisnika"] == '2' )) {
        echo "<section class = \"section_id5\">";
        echo "<h1>Editiranje slike</h1>";
        echo "</section>";
        echo "<section class = \"section_id10\">";
        echo "<form name=\"editiranje_slike\" method=\"post\" action= \"{$_SERVER["PHP_SELF"]}\">";
        echo "<div>";

        $get_podaci = $_SERVER["QUERY_STRING"];

        $podaci_s_get_ex = explode("&",$get_podaci);
        
        $get_slika_id = (int) filter_var($podaci_s_get_ex[2],FILTER_SANITIZE_NUMBER_INT);

        echo "<div>";
        $upit = "SELECT
          s.slika_id,
          s.planina_id,
          s.naziv,
          s.url,
          s.opis,
          s.datum_vrijeme_slikanja,
          p.naziv,
          p.planina_id,
          s.status
          FROM
            slika AS s
          LEFT JOIN planina as p ON s.planina_id=p.planina_id
          WHERE s.slika_id = \"$get_slika_id\"";
        $rezultat_slika = izvrsiUpit($veza, $upit);
        $podatak_slika = mysqli_fetch_array($rezultat_slika);

        $upit = "SELECT * FROM PLANINA";
        $rezultat_planina = izvrsiUpit($veza, $upit);

        $status_ispis = "";

        if ($podatak_slika[8] == '0') {
          $status_ispis = "Privatna";
        }
        else {
          $status_ispis = "Javna";
        }

        echo "<label for=\"pla_id\"><b>PLANINA: </b></label>";
        echo "<select id=\"pla_id\" name=\"pla_id\">";

        echo "<option value = \"$podatak_slika[7]\" selected hidden >$podatak_slika[6]</option>";
        while($podatak_planina= mysqli_fetch_array($rezultat_planina)){
          echo "<option value='{$podatak_planina[0]}'";
          echo ">{$podatak_planina[1]}</option>";
        }
        echo "</select>";
        echo "</div>";
        echo "<div>";
        echo "<label for=\"slika_ime\"><b>NAZIV SLIKE:</b> </label>";
        echo "<input id=\"slika_ime\" name=\"slika_ime\" type=\"text\" value=\"$podatak_slika[2]\" />";
        echo "</div>";
        echo "<div>";
        echo "<label for=\"slika_url\"><b>URL SLIKE: </b></label>";
        echo "<input id=\"slika_url\" name=\"slika_url\" type=\"text\" value=\"$podatak_slika[3]\" />";
        echo "</div>";
        echo "<div>";
        echo "<label for=\"slika_opis\"><b>OPIS: </b></label>";
        echo "<input id=\"slika_opis\" name=\"slika_opis\" type=\"text\" value=\"$podatak_slika[4]\" />";
        echo "</div>";
        echo "<div> ";
        echo "<label for=\"slika_vrijeme\"><b>DATUM I VRIJEME SLIKANJA: </b></label>";

        $get_od_datuma_d =substr($podatak_slika[5],0,4);
        $get_od_datuma_m =substr($podatak_slika[5],5,2);
        $get_od_datuma_Y =substr($podatak_slika[5],8,2);
        $get_od_datuma_H_i_s =substr($podatak_slika[5],11,8);
        $novi_datum_za_bazu = $get_od_datuma_Y . "-" . $get_od_datuma_m . "-" . $get_od_datuma_d . " " . $get_od_datuma_H_i_s;

        echo "<input id=\"slika_vrijeme\" name=\"slika_vrijeme\" type=\"text\" maxlength = \"19\" value=\"$novi_datum_za_bazu\" />";
        echo "</div>";
        echo "<div>";
        echo "<label for=\"slika_status\"><b>STATUS: </b></label>";
        echo "<select id=\"slika_status\" name=\"slika_status\">";

        echo "<option value = \"$podatak_slika[8]\" selected hidden >$status_ispis</option>";
        echo "<option value=\"0\">Privatna</option>";
        echo "<option value=\"1\">Javna</option>";
        echo "</select>";
        echo "</div>";
        echo "<div>";
        echo "<label hidden for=\"slika_id\"></label>";
        echo "<input hidden id=\"slika_id\" name=\"slika_id\" type=\"text\" value=\"$podatak_slika[0]\" />";
        echo "</div>";
        echo "<div>";
        echo "<label for=\"delete\"><b>OBRISATI SLIKU?</b></label>";
        echo "<select id=\"delete\" name=\"delete\">";
        echo "<option value=\"1\">Da</option>";
        echo "<option value=\"0\"selected>Ne</option>";
        echo "</select>";
        echo "</div>";
        echo "<div>";
        echo "<input class=\"gumb\" type=\"submit\" value=\"Ažuriraj\" />";  
        echo "</div>";
        echo "</form>";
        echo "</section>";

      }

      zatvoriVezuNaBazu($veza);
      include("prazni.php");
      include_once("footer.php");
    ?>
  </body>

</html>