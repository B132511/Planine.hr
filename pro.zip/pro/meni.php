<header>
    <?php
        echo "<div class=\"header_div_prazni_prvi\"></div>";
        echo "<div>";
        echo "<p>HR PLANINE.<p>";
        echo "</div>";
        echo "<div class=\"header_div_prazni_drugi\"></div>";
        echo "<div>";
        echo "<a class = \"editirani\" href=\"index.php\">početna stranica</a>";
        echo "</div>";
        echo "<div>";
        echo "<a class = \"editirani\" href=\"galerija.php\">galerija</a>";
        echo "</div>";
        if (isset($_SESSION) && !empty($_SESSION)){
            echo "<div>";
            echo "<a class = \"editirani\" href=\"moj_profil.php\">moj profil</a>";
            echo "</div>";
            echo "<div>";
            echo "<a class = \"editirani\" href=\"odjava.php\">Odjava</a>";
            echo "</div>";
        }
        else {
            echo "<div>";
            echo "<a class = \"editirani\" href=\"prijava.php\">Prijava</a>";
            echo "</div>";
        }

        echo "<div class=\"header_div_prazni_zadnji\"></div>";
    ?>
</header>