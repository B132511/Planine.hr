<?php

  session_start();
  
  include_once("baza.php");
  include_once("meni.php");
  include_once ("slika.php");
  include("prazni.php");

  $veza = spojiSeNaBazu();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
      <meta charset="utf-8">
      <meta name="autor" content="Borna Alvir">
      <meta name="datum" content="16.01.2022.">
      <link rel="stylesheet" type="text/css" href="CSS/Glavni.css">
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
      <title>HR PLANINE</title>
  </head>
  <body>
    <?php
      if (isset($_SESSION["tip_korisnika"]) && $_SESSION["tip_korisnika"] == '0' || $_SESSION["tip_korisnika"] == '1' || $_SESSION["tip_korisnika"] == '2' ) {
        echo "<section class = \"section_id5\">";
        echo "<h1>Nova planina</h1>";
        echo "</section>";
        echo "<section class = \"section_id10\">";
        echo "<form name=\"registracija_planine\" method=\"post\" action= \"{$_SERVER["PHP_SELF"]}\">";

        echo "<div>";
        echo "<label for=\"pla_naziv\">NAZIV PLANINE: </label>";
        echo "<input id=\"pla_naziv\" name=\"pla_naziv\" type=\"text\" />";
        echo "</div>";

        echo "<div>";
        echo "<label for=\"pla_opis\">OPIS: </label>";
        echo "<input id=\"pla_opis\" name=\"pla_opis\" type=\"text\" />";
        echo "</div>";

        echo "<div>";
        echo "<label for=\"pla_lok\">LOKACIJA: </label>";
        echo "<input id=\"pla_lok\" name=\"pla_lok\" type=\"text\" />";
        echo "</div>";

        echo "<div>";
        echo "<label for=\"pla_geos\">GEOGRAFSKA ŠIRINA: </label>";
        echo "<input id=\"pla_geos\" name=\"pla_geos\" type=\"decimal\" />";
        echo "</div>";

        echo "<div> ";
        echo "<label for=\"pla_geod\">GEOGRAFSKA DUŽINA </label>";
        echo "<input id=\"pla_geod\" name=\"pla_geod\" type=\"decimal\"  />";
        echo "</div>";

        echo "<div>";
        echo "<input class=\"gumb\" type=\"submit\" value=\"Upload\" />";  
        echo "</div>";
        echo "</form>";
        echo "</section>";
        
      }

      if ($_SERVER["REQUEST_METHOD"] == 'POST') {
        $poruka_greske_upisa = "";
        $poh_pla_naziv = "{$_POST["pla_naziv"]}";
        $poh_pla_opis = "{$_POST["pla_opis"]}";
        $poh_pla_lok = "{$_POST["pla_lok"]}";
        $poh_pla_geos = "{$_POST["pla_geos"]}";
        $poh_pla_geod = "{$_POST["pla_geod"]}";
      
        if (!isset($poh_pla_naziv) || empty($poh_pla_naziv)) {
          $poruka_greske_upisa .= "Niste unijeli naziv planine!<br>";
        }

        if (!isset($poh_pla_opis) || empty($poh_pla_opis)) {
          $poruka_greske_upisa .= "Niste unijeli opis planine!<br>";
        }

      }
      
      if (empty($poruka_greske_upisa) && $_SERVER["REQUEST_METHOD"] == 'POST') {

        $poruka_uspjesnog_uplouda = "";
        $poruka_uspjesnog_uplouda_planine = "";

        $upit = "INSERT INTO `planina` (`naziv`, `opis`, `lokacija`, `geografska_sirina`, `geografska_duzina`) 
        VALUES ('{$poh_pla_naziv}', '{$poh_pla_opis}', '{$poh_pla_lok}', '{$poh_pla_geos}', '{$poh_pla_geod}')";
    
        izvrsiUpit($veza, $upit);
    
        $id_nove_slike = mysqli_insert_id($veza);
    
        $poruka_uspjesnog_uplouda .= "Uspješno ste kreirali novu planinu!";
        $poruka_uspjesnog_uplouda_planine .= "Vaša slika se nalazi pod ID brojem: $id_nove_slike";
    
      }
        
      if (isset($poruka_greske_upisa) && $_SERVER["REQUEST_METHOD"] == 'POST') {
        echo "<section class = \"section_id10\">";
        echo "$poruka_greske_upisa";
        echo "</section>";
      }

      if (isset($poruka_uspjesnog_uplouda) && isset($poruka_uspjesnog_uplouda_planine) && $_SERVER["REQUEST_METHOD"] == 'POST') {
        echo "<section class = \"section_id10\">";
        echo "$poruka_uspjesnog_uplouda";
        echo "<br>";
        echo "$poruka_uspjesnog_uplouda_planine";
        echo "</section>";
      }
      
      zatvoriVezuNaBazu($veza);
      include("prazni.php");
      include_once("footer.php");
    ?>
  </body>

</html>