<?php

  session_start();
  
  include_once("meni.php");
  include_once ("slika.php");
  include_once ("baza.php");
  include ("prazni.php");

  $get_podaci = $_SERVER["QUERY_STRING"];

  $podaci_s_get_ex = explode("&",$get_podaci);

  $get_planina_id =(int) filter_var($podaci_s_get_ex[0],FILTER_SANITIZE_NUMBER_INT);
  $get_korisnik_id = (int) filter_var($podaci_s_get_ex[1],FILTER_SANITIZE_NUMBER_INT);
  $get_slika_id = (int) filter_var($podaci_s_get_ex[2],FILTER_SANITIZE_NUMBER_INT);

  $veza = spojiSeNaBazu();

  echo "<section class = \"section_id7\">";

  $upit = "SELECT * FROM `slika` where slika_id = \"$get_slika_id\"";

  $rezultat = izvrsiUpit($veza, $upit);

  echo "<h1>SLIKA</h1>";

  while ($podaci = mysqli_fetch_array($rezultat)) {
    echo "<div>";
    echo "<img border=\"0\"  alt=\"foi.hr\" src=\"$podaci[4]\" width=\"500px\" height=\"300px\"></a>";
    echo "<p><b>Naziv slike: </b> $podaci[3]</p>";
    echo "<p><b>Opis slike: </b> $podaci[5]</p>";

    $get_od_datuma_d =substr($podaci[6],0,4);
    $get_od_datuma_m =substr($podaci[6],5,2);
    $get_od_datuma_Y =substr($podaci[6],8,2);
    $get_od_datuma_H_i_s =substr($podaci[6],11,8);
    $novi_datum_za_bazu = $get_od_datuma_Y . "-" . $get_od_datuma_m . "-" . $get_od_datuma_d . " " . $get_od_datuma_H_i_s;

    echo "<p><b>Vrijeme slikanja: </b>$novi_datum_za_bazu</p>";
    echo "</div>";
  }

  $upit = "SELECT * FROM `planina` WHERE planina_id =\"$get_planina_id\"";

  $rezultat = izvrsiUpit($veza, $upit);

  echo "<h1>PLANINA</h1>";

  while ($podaci = mysqli_fetch_array($rezultat)) {
    echo "<div>";
    echo "<p><b>Naziv: </b> <a href=\"galerija.php?$get_planina_id\">$podaci[1]</a></p>";
    echo "<p><b>Opis: </b> $podaci[2]</p>";
    echo "<p><b>Lokacija :</b> $podaci[3]</p>";
    echo "<p><b>Geografska širina: </b> $podaci[4]</p>";
    echo "<p><b>Geografska dužina: </b> $podaci[5]</p>";
    echo "</div>";
  }

  $upit = "SELECT * FROM `korisnik` WHERE korisnik_id =\"$get_korisnik_id\"";

  $rezultat = izvrsiUpit($veza, $upit);

  echo "<h1>FOTOGRAF</h1>";

  while ($podaci = mysqli_fetch_array($rezultat)) {
    echo "<div>";
    echo "<p><b>Korisničko ime: </b> $podaci[2]</p>";
    echo "<p><b>Ime: </b> $podaci[4]</p>";
    echo "<p><b>Prezime: </b><a href=\"javni_profil.php?$get_podaci\">$podaci[5]</a></p>";
    echo "</div>";
  }

  echo "</section>";

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="autor" content="Borna Alvir">
  <meta name="datum" content="16.01.2022.">
  <link rel="stylesheet" type="text/css" href="CSS/Glavni.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
  <title>HR PLANINE</title>
</head>
<body>
  <?php
    zatvoriVezuNaBazu($veza);
    include ("prazni.php");
    include_once ("footer.php");
  ?>
</body>


</html>