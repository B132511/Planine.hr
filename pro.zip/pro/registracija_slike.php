<?php

  session_start();
  
  include_once("baza.php");
  include_once("meni.php");
  include_once ("slika.php");
  include("prazni.php");

  $veza = spojiSeNaBazu();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
      <meta charset="utf-8">
      <meta name="autor" content="Borna Alvir">
      <meta name="datum" content="16.01.2022.">
      <link rel="stylesheet" type="text/css" href="CSS/Glavni.css">
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
      <title>HR PLANINE</title>
  </head>
  <body>
    <?php
      if (isset($_SESSION["tip_korisnika"]) && $_SESSION["tip_korisnika"] == '0' || $_SESSION["tip_korisnika"] == '1' || $_SESSION["tip_korisnika"] == '2' ) {
        echo "<section class = \"section_id5\">";
        echo "<h1>upload nove slike</h1>";
        echo "</section>";
        echo "<section class = \"section_id10\">";
        echo "<form name=\"registracija_slike\" method=\"post\" action= \"{$_SERVER["PHP_SELF"]}\">";
        echo "<div>";
        $upit = "SELECT * FROM planina";
        $rezultat_planina = izvrsiUpit($veza, $upit);
        echo "<label for=\"slika_planina\">NAZIV PLANINE: </label>";
        echo "<select id=\"slika_planina\" name=\"slika_planina\">";
        echo "<option value = \"\" selected hidden >Odaberite planinu</option>";
          while($podaci_planina = mysqli_fetch_array($rezultat_planina)){
            echo "<option value='{$podaci_planina[0]}'";
            echo ">{$podaci_planina[1]}</option>";
          }
        echo "</select>";
        echo "</div>";
        echo "<div>";
        echo "<label for=\"slika_ime\">NAZIV SLIKE: </label>";
        echo "<input id=\"slika_ime\" name=\"slika_ime\" type=\"text\" />";
        echo "</div>";
        echo "<div>";
        echo "<label for=\"slika_url\">URL SLIKE: </label>";
        echo "<input id=\"slika_url\" name=\"slika_url\" type=\"text\" />";
        echo "</div>";
        echo "<div>";
        echo "<label for=\"slika_opis\">OPIS: </label>";
        echo "<input id=\"slika_opis\" name=\"slika_opis\" type=\"text\" />";
        echo "</div>";
        echo "<div> ";
        echo "<label for=\"slika_vrijeme\">DATUM I VRIJEME SLIKANJA: </label>";
        echo "<input id=\"slika_vrijeme\" name=\"slika_vrijeme\" type=\"text\" maxlength = \"19\" placeholder=\"dd-mm-YYYY HH:ii:ss\" />";
        echo "</div>";
        echo "<div>";
        echo "<input class=\"gumb\" type=\"submit\" value=\"Upload\" />";  
        echo "</div>";
        echo "</form>";
        echo "</section>";
        
      }

      if ($_SERVER["REQUEST_METHOD"] == 'POST') {
        $poruka_greske_upisa = "";
        $poh_slika_planina = "{$_POST["slika_planina"]}";
        $poh_slika_ime = "{$_POST["slika_ime"]}";
        $poh_slika_url= "{$_POST["slika_url"]}";
        $poh_slika_opis = "{$_POST["slika_opis"]}";
        $poh_slika_vrijeme = "{$_POST["slika_vrijeme"]}";
        $poh_korisnik_id = "{$_SESSION["korisnik_id"]}";
      
        if (!isset($poh_slika_planina) || empty($poh_slika_planina)) {
          $poruka_greske_upisa .= "Niste unijeli naziv planine! <br>";
        }

        if (!isset($poh_slika_ime) || empty($poh_slika_ime)) {
          $poruka_greske_upisa .= "Niste unijeli ime slike! <br>";
        }

        if (!isset($poh_slika_url) || empty($poh_slika_url)) {
          $poruka_greske_upisa .= "Niste unijeli URL slike! <br>";
        }

        if (!isset($poh_slika_opis) || empty($poh_slika_opis)) {
          $poruka_greske_upisa .= "Niste unijeli opis slike! <br>";
        }

        if (!isset($poh_slika_vrijeme) || empty($poh_slika_vrijeme)) {
          $poruka_greske_upisa .= "Niste unijeli vrijeme slike! <br>";
        }

        if (
        !strlen($poh_slika_vrijeme) == '19' ||
        !is_numeric(substr($poh_slika_vrijeme,0,2)) ||
        !is_numeric(substr($poh_slika_vrijeme,3,2)) ||
        !is_numeric(substr($poh_slika_vrijeme,6,4)) ||
        !is_numeric(substr($poh_slika_vrijeme,11,2)) ||
        !is_numeric(substr($poh_slika_vrijeme,14,2)) ||
        !is_numeric(substr($poh_slika_vrijeme,17,2)) ||
        !substr_count(substr($poh_slika_vrijeme,2,1),'-') == '1' ||
        !substr_count(substr($poh_slika_vrijeme,5,1),'-') == '1' ||
        !substr_count(substr($poh_slika_vrijeme,13,1),':') == '1' ||
        !substr_count(substr($poh_slika_vrijeme,16,1),':') == '1'
        ) {
          $poruka_greske_upisa .= "Niste unijeli ispravno vrijeme slike!";
        }

      }
      
      if (empty($poruka_greske_upisa) && $_SERVER["REQUEST_METHOD"] == 'POST') {
        $get_od_datuma_d =substr($poh_slika_vrijeme,0,2);
        $get_od_datuma_m =substr($poh_slika_vrijeme,3,2);
        $get_od_datuma_Y =substr($poh_slika_vrijeme,6,4);
        $get_od_datuma_H_i_s =substr($poh_slika_vrijeme,11,8);
        $novi_datum_za_bazu = $get_od_datuma_Y . "-" . $get_od_datuma_m . "-" . $get_od_datuma_d . " " . $get_od_datuma_H_i_s;

        $poruka_uspjesnog_uplouda = "";
        $poruka_uspjesnog_uplouda_slike = "";
        $upit = "INSERT INTO slika (planina_id, korisnik_id, naziv, url, opis, datum_vrijeme_slikanja, status) 
        VALUES ('{$poh_slika_planina}', '{$poh_korisnik_id}', '{$poh_slika_ime}', '{$poh_slika_url}', '{$poh_slika_opis}', '{$novi_datum_za_bazu}', 1)";
    
        izvrsiUpit($veza, $upit);
    
        $id_nove_slike = mysqli_insert_id($veza);
    
        $poruka_uspjesnog_uplouda .= "Uspješno ste postavili novu sliku u galeriji HR PLANINE.!";
        $poruka_uspjesnog_uplouda_slike .= "Vaša slika se nalazi pod ID brojem: $id_nove_slike";
    
      }
        
      if (isset($poruka_greske_upisa) && $_SERVER["REQUEST_METHOD"] == 'POST') {
        echo "<section class = \"section_id10\">";
        echo "$poruka_greske_upisa";
        echo "</section>";
      }

      if (isset($poruka_uspjesnog_uplouda) && isset($poruka_uspjesnog_uplouda_slike) && $_SERVER["REQUEST_METHOD"] == 'POST') {
        echo "<section class = \"section_id10\">";
        echo "$poruka_uspjesnog_uplouda";
        echo "<br>";
        echo "$poruka_uspjesnog_uplouda_slike";
        echo "</section>";
      }
      
      zatvoriVezuNaBazu($veza);
      include("prazni.php");
      include_once("footer.php");
    ?>
  </body>

</html>